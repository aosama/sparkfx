package org.createathon.blueinvestigate.di.dbconnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.dbcp2.BasicDataSource;
import org.createathon.blueinvestigate.di.entities.Tbldatasources;
import org.createathon.blueinvestigate.di.entities.Tblentitytypes;
import org.createathon.blueinvestigate.di.entities.Tbltablemappings;
import org.createathon.blueinvestigate.di.facade.BaseFacade;
import org.createathon.blueinvestigate.di.facade.FacadeEntityTypes;

/**
 * @author Ahmed Ibrahim
 *
 */
public class ConnectionFactory extends BaseFacade {

  private final FacadeEntityTypes facadeEntityTypes = new FacadeEntityTypes();
  private final static HashMap<String, BasicDataSource> dataSourcesMap = new HashMap<>();

  public List<Tbltablemappings> findTableMappingsForEntity(String entityName) {
    Tblentitytypes e = facadeEntityTypes.findEntityTypeByName(entityName);
    return e.getTbltablemappingsList();
  }

  public Connection getConnectionForEntityMapping(Tbltablemappings entityMapping) throws SQLException {
    return getConnectionFromDataSource(entityMapping.getMappedDataSourceId());
  }

  public Connection getConnectionFromDataSource(Tbldatasources ds) throws SQLException {
    //check if the datasource is already created or not
    BasicDataSource dataSource = dataSourcesMap.get(ds.getDataSourceName());
    if (dataSource == null) {
      dataSource = new BasicDataSource();
      dataSource.setDriverClassName(ds.getDataSourceJDBCDriver());
      dataSource.setUrl(ds.getDataSourceJdbcUrl());
      dataSource.setMaxTotal(100);
      dataSourcesMap.put(ds.getDataSourceName(), dataSource);
      System.out.println("creating new data source for " + ds.getDataSourceName());
    }
    return dataSource.getConnection();
  }
}
