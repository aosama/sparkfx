/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author aosama
 */
@Entity
@Table(name = "tbldatasources")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Tbldatasources.findAll", query = "SELECT t FROM Tbldatasources t")
  , @NamedQuery(name = "Tbldatasources.findByDataSourceID", query = "SELECT t FROM Tbldatasources t WHERE t.dataSourceID = :dataSourceID")
  , @NamedQuery(name = "Tbldatasources.findByDataSourceJdbcUrl", query = "SELECT t FROM Tbldatasources t WHERE t.dataSourceJdbcUrl = :dataSourceJdbcUrl")
  , @NamedQuery(name = "Tbldatasources.findByDataSourceName", query = "SELECT t FROM Tbldatasources t WHERE t.dataSourceName = :dataSourceName")
  , @NamedQuery(name = "Tbldatasources.findByDataSourceJDBCDriver", query = "SELECT t FROM Tbldatasources t WHERE t.dataSourceJDBCDriver = :dataSourceJDBCDriver")
  , @NamedQuery(name = "Tbldatasources.findByDataSourceUser", query = "SELECT t FROM Tbldatasources t WHERE t.dataSourceUser = :dataSourceUser")
  , @NamedQuery(name = "Tbldatasources.findByDataSourcePass", query = "SELECT t FROM Tbldatasources t WHERE t.dataSourcePass = :dataSourcePass")})
public class Tbldatasources implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "dataSourceID")
  private Integer dataSourceID;
  @Basic(optional = false)
  @Column(name = "dataSourceJdbcUrl")
  private String dataSourceJdbcUrl;
  @Basic(optional = false)
  @Column(name = "dataSourceName")
  private String dataSourceName;
  @Column(name = "dataSourceJDBCDriver")
  private String dataSourceJDBCDriver;
  @Column(name = "dataSourceUser")
  private String dataSourceUser;
  @Column(name = "dataSourcePass")
  private String dataSourcePass;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "mappedDataSourceId")
  private List<Tbltablemappings> tbltablemappingsList;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "mappedDataSourceId")
  private List<Tbllinkmapping> tbllinkmappingList;

  public Tbldatasources() {
  }

  public Tbldatasources(Integer dataSourceID) {
    this.dataSourceID = dataSourceID;
  }

  public Tbldatasources(Integer dataSourceID, String dataSourceJdbcUrl, String dataSourceName) {
    this.dataSourceID = dataSourceID;
    this.dataSourceJdbcUrl = dataSourceJdbcUrl;
    this.dataSourceName = dataSourceName;
  }

  public Integer getDataSourceID() {
    return dataSourceID;
  }

  public void setDataSourceID(Integer dataSourceID) {
    this.dataSourceID = dataSourceID;
  }

  public String getDataSourceJdbcUrl() {
    return dataSourceJdbcUrl;
  }

  public void setDataSourceJdbcUrl(String dataSourceJdbcUrl) {
    this.dataSourceJdbcUrl = dataSourceJdbcUrl;
  }

  public String getDataSourceName() {
    return dataSourceName;
  }

  public void setDataSourceName(String dataSourceName) {
    this.dataSourceName = dataSourceName;
  }

  public String getDataSourceJDBCDriver() {
    return dataSourceJDBCDriver;
  }

  public void setDataSourceJDBCDriver(String dataSourceJDBCDriver) {
    this.dataSourceJDBCDriver = dataSourceJDBCDriver;
  }

  public String getDataSourceUser() {
    return dataSourceUser;
  }

  public void setDataSourceUser(String dataSourceUser) {
    this.dataSourceUser = dataSourceUser;
  }

  public String getDataSourcePass() {
    return dataSourcePass;
  }

  public void setDataSourcePass(String dataSourcePass) {
    this.dataSourcePass = dataSourcePass;
  }

  @XmlTransient
  public List<Tbltablemappings> getTbltablemappingsList() {
    return tbltablemappingsList;
  }

  public void setTbltablemappingsList(List<Tbltablemappings> tbltablemappingsList) {
    this.tbltablemappingsList = tbltablemappingsList;
  }

  @XmlTransient
  public List<Tbllinkmapping> getTbllinkmappingList() {
    return tbllinkmappingList;
  }

  public void setTbllinkmappingList(List<Tbllinkmapping> tbllinkmappingList) {
    this.tbllinkmappingList = tbllinkmappingList;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (dataSourceID != null ? dataSourceID.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Tbldatasources)) {
      return false;
    }
    Tbldatasources other = (Tbldatasources) object;
    if ((this.dataSourceID == null && other.dataSourceID != null) || (this.dataSourceID != null && !this.dataSourceID.equals(other.dataSourceID))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "org.createathon.blueinvestigate.di.entities.Tbldatasources[ dataSourceID=" + dataSourceID + " ]";
  }

}
