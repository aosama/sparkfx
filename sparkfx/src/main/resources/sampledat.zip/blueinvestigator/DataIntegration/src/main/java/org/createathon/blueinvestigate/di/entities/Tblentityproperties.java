/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author aosama
 */
@Entity
@Table(name = "tblentityproperties")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Tblentityproperties.findAll", query = "SELECT t FROM Tblentityproperties t")
  , @NamedQuery(name = "Tblentityproperties.findByPropertyId", query = "SELECT t FROM Tblentityproperties t WHERE t.propertyId = :propertyId")
  , @NamedQuery(name = "Tblentityproperties.findByPropName", query = "SELECT t FROM Tblentityproperties t WHERE t.propName = :propName")
  , @NamedQuery(name = "Tblentityproperties.findByPropType", query = "SELECT t FROM Tblentityproperties t WHERE t.propType = :propType")
  , @NamedQuery(name = "Tblentityproperties.findByPrimaryKey", query = "SELECT t FROM Tblentityproperties t WHERE t.primaryKey = :primaryKey")
  , @NamedQuery(name = "Tblentityproperties.findByLabel", query = "SELECT t FROM Tblentityproperties t WHERE t.label = :label")})
public class Tblentityproperties implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "propertyId")
  private Long propertyId;
  @Basic(optional = false)
  @Column(name = "propName")
  private String propName;
  @Basic(optional = false)
  @Column(name = "propType")
  private String propType;
  @Basic(optional = false)
  @Column(name = "primaryKey")
  private int primaryKey;
  @Basic(optional = false)
  @Column(name = "Label")
  private int label;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertyId")
  private List<Tblpropmapping> tblpropmappingList;
  @JoinColumn(name = "entityId", referencedColumnName = "EntityId")
  @ManyToOne(optional = false)
  private Tblentitytypes entityId;
  @OneToMany(mappedBy = "fromEntityPropId")
  private List<Tbllinkpropmapping> tbllinkpropmappingList;
  @OneToMany(mappedBy = "toEntityPropId")
  private List<Tbllinkpropmapping> tbllinkpropmappingList1;

  public Tblentityproperties() {
  }

  public Tblentityproperties(Long propertyId) {
    this.propertyId = propertyId;
  }

  public Tblentityproperties(Long propertyId, String propName, String propType, int primaryKey, int label) {
    this.propertyId = propertyId;
    this.propName = propName;
    this.propType = propType;
    this.primaryKey = primaryKey;
    this.label = label;
  }

  public Long getPropertyId() {
    return propertyId;
  }

  public void setPropertyId(Long propertyId) {
    this.propertyId = propertyId;
  }

  public String getPropName() {
    return propName;
  }

  public void setPropName(String propName) {
    this.propName = propName;
  }

  public String getPropType() {
    return propType;
  }

  public void setPropType(String propType) {
    this.propType = propType;
  }

  public int getPrimaryKey() {
    return primaryKey;
  }

  public void setPrimaryKey(int primaryKey) {
    this.primaryKey = primaryKey;
  }

  public int getLabel() {
    return label;
  }

  public void setLabel(int label) {
    this.label = label;
  }

  @XmlTransient
  public List<Tblpropmapping> getTblpropmappingList() {
    return tblpropmappingList;
  }

  public void setTblpropmappingList(List<Tblpropmapping> tblpropmappingList) {
    this.tblpropmappingList = tblpropmappingList;
  }

  public Tblentitytypes getEntityId() {
    return entityId;
  }

  public void setEntityId(Tblentitytypes entityId) {
    this.entityId = entityId;
  }

  @XmlTransient
  public List<Tbllinkpropmapping> getTbllinkpropmappingList() {
    return tbllinkpropmappingList;
  }

  public void setTbllinkpropmappingList(List<Tbllinkpropmapping> tbllinkpropmappingList) {
    this.tbllinkpropmappingList = tbllinkpropmappingList;
  }

  @XmlTransient
  public List<Tbllinkpropmapping> getTbllinkpropmappingList1() {
    return tbllinkpropmappingList1;
  }

  public void setTbllinkpropmappingList1(List<Tbllinkpropmapping> tbllinkpropmappingList1) {
    this.tbllinkpropmappingList1 = tbllinkpropmappingList1;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (propertyId != null ? propertyId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Tblentityproperties)) {
      return false;
    }
    Tblentityproperties other = (Tblentityproperties) object;
    if ((this.propertyId == null && other.propertyId != null) || (this.propertyId != null && !this.propertyId.equals(other.propertyId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "org.createathon.blueinvestigate.di.entities.Tblentityproperties[ propertyId=" + propertyId + " ]";
  }

}
