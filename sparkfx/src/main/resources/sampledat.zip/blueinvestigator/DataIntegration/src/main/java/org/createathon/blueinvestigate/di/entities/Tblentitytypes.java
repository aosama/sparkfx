/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author aosama
 */
@Entity
@Table(name = "tblentitytypes")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Tblentitytypes.findAll", query = "SELECT t FROM Tblentitytypes t")
  , @NamedQuery(name = "Tblentitytypes.findByEntityId", query = "SELECT t FROM Tblentitytypes t WHERE t.entityId = :entityId")
  , @NamedQuery(name = "Tblentitytypes.findByEntityName", query = "SELECT t FROM Tblentitytypes t WHERE t.entityName = :entityName")})
public class Tblentitytypes implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "EntityId")
  private Integer entityId;
  @Basic(optional = false)
  @Column(name = "EntityName")
  private String entityName;
  @Lob
  @Column(name = "DefaultImage")
  private byte[] defaultImage;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "mappedEntityId")
  private List<Tbltablemappings> tbltablemappingsList;
  @OneToMany(mappedBy = "parent")
  private List<Tblentitytypes> tblentitytypesList;
  @JoinColumn(name = "parent", referencedColumnName = "EntityId")
  @ManyToOne
  private Tblentitytypes parent;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "linkFromEntity")
  private List<Tbllinktypes> tbllinktypesList;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "linkToEntity")
  private List<Tbllinktypes> tbllinktypesList1;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "entityId")
  private List<Tblentityproperties> tblentitypropertiesList;

  public Tblentitytypes() {
  }

  public Tblentitytypes(Integer entityId) {
    this.entityId = entityId;
  }

  public Tblentitytypes(Integer entityId, String entityName) {
    this.entityId = entityId;
    this.entityName = entityName;
  }

  public Integer getEntityId() {
    return entityId;
  }

  public void setEntityId(Integer entityId) {
    this.entityId = entityId;
  }

  public String getEntityName() {
    return entityName;
  }

  public void setEntityName(String entityName) {
    this.entityName = entityName;
  }

  public byte[] getDefaultImage() {
    return defaultImage;
  }

  public void setDefaultImage(byte[] defaultImage) {
    this.defaultImage = defaultImage;
  }

  @XmlTransient
  public List<Tbltablemappings> getTbltablemappingsList() {
    return tbltablemappingsList;
  }

  public void setTbltablemappingsList(List<Tbltablemappings> tbltablemappingsList) {
    this.tbltablemappingsList = tbltablemappingsList;
  }

  @XmlTransient
  public List<Tblentitytypes> getTblentitytypesList() {
    return tblentitytypesList;
  }

  public void setTblentitytypesList(List<Tblentitytypes> tblentitytypesList) {
    this.tblentitytypesList = tblentitytypesList;
  }

  public Tblentitytypes getParent() {
    return parent;
  }

  public void setParent(Tblentitytypes parent) {
    this.parent = parent;
  }

  @XmlTransient
  public List<Tbllinktypes> getTbllinktypesList() {
    return tbllinktypesList;
  }

  public void setTbllinktypesList(List<Tbllinktypes> tbllinktypesList) {
    this.tbllinktypesList = tbllinktypesList;
  }

  @XmlTransient
  public List<Tbllinktypes> getTbllinktypesList1() {
    return tbllinktypesList1;
  }

  public void setTbllinktypesList1(List<Tbllinktypes> tbllinktypesList1) {
    this.tbllinktypesList1 = tbllinktypesList1;
  }

  @XmlTransient
  public List<Tblentityproperties> getTblentitypropertiesList() {
    return tblentitypropertiesList;
  }

  public void setTblentitypropertiesList(List<Tblentityproperties> tblentitypropertiesList) {
    this.tblentitypropertiesList = tblentitypropertiesList;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (entityId != null ? entityId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Tblentitytypes)) {
      return false;
    }
    Tblentitytypes other = (Tblentitytypes) object;
    if ((this.entityId == null && other.entityId != null) || (this.entityId != null && !this.entityId.equals(other.entityId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "org.createathon.blueinvestigate.di.entities.Tblentitytypes[ entityId=" + entityId + " ]";
  }

}
