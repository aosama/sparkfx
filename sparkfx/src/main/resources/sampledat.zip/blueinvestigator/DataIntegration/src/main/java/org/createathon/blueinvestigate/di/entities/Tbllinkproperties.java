/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author aosama
 */
@Entity
@Table(name = "tbllinkproperties")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Tbllinkproperties.findAll", query = "SELECT t FROM Tbllinkproperties t")
  , @NamedQuery(name = "Tbllinkproperties.findByLinkPropertyId", query = "SELECT t FROM Tbllinkproperties t WHERE t.linkPropertyId = :linkPropertyId")
  , @NamedQuery(name = "Tbllinkproperties.findByPropertyName", query = "SELECT t FROM Tbllinkproperties t WHERE t.propertyName = :propertyName")
  , @NamedQuery(name = "Tbllinkproperties.findByPropertyDataType", query = "SELECT t FROM Tbllinkproperties t WHERE t.propertyDataType = :propertyDataType")
  , @NamedQuery(name = "Tbllinkproperties.findByPrimaryKey", query = "SELECT t FROM Tbllinkproperties t WHERE t.primaryKey = :primaryKey")
  , @NamedQuery(name = "Tbllinkproperties.findByLabel", query = "SELECT t FROM Tbllinkproperties t WHERE t.label = :label")})
public class Tbllinkproperties implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "linkPropertyId")
  private Integer linkPropertyId;
  @Basic(optional = false)
  @Column(name = "propertyName")
  private String propertyName;
  @Basic(optional = false)
  @Column(name = "propertyDataType")
  private String propertyDataType;
  @Basic(optional = false)
  @Column(name = "PrimaryKey")
  private int primaryKey;
  @Basic(optional = false)
  @Column(name = "Label")
  private int label;
  @JoinColumn(name = "LinkId", referencedColumnName = "LinkId")
  @ManyToOne(optional = false)
  private Tbllinktypes linkId;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertyId")
  private List<Tbllinkpropmapping> tbllinkpropmappingList;

  public Tbllinkproperties() {
  }

  public Tbllinkproperties(Integer linkPropertyId) {
    this.linkPropertyId = linkPropertyId;
  }

  public Tbllinkproperties(Integer linkPropertyId, String propertyName, String propertyDataType, int primaryKey, int label) {
    this.linkPropertyId = linkPropertyId;
    this.propertyName = propertyName;
    this.propertyDataType = propertyDataType;
    this.primaryKey = primaryKey;
    this.label = label;
  }

  public Integer getLinkPropertyId() {
    return linkPropertyId;
  }

  public void setLinkPropertyId(Integer linkPropertyId) {
    this.linkPropertyId = linkPropertyId;
  }

  public String getPropertyName() {
    return propertyName;
  }

  public void setPropertyName(String propertyName) {
    this.propertyName = propertyName;
  }

  public String getPropertyDataType() {
    return propertyDataType;
  }

  public void setPropertyDataType(String propertyDataType) {
    this.propertyDataType = propertyDataType;
  }

  public int getPrimaryKey() {
    return primaryKey;
  }

  public void setPrimaryKey(int primaryKey) {
    this.primaryKey = primaryKey;
  }

  public int getLabel() {
    return label;
  }

  public void setLabel(int label) {
    this.label = label;
  }

  public Tbllinktypes getLinkId() {
    return linkId;
  }

  public void setLinkId(Tbllinktypes linkId) {
    this.linkId = linkId;
  }

  @XmlTransient
  public List<Tbllinkpropmapping> getTbllinkpropmappingList() {
    return tbllinkpropmappingList;
  }

  public void setTbllinkpropmappingList(List<Tbllinkpropmapping> tbllinkpropmappingList) {
    this.tbllinkpropmappingList = tbllinkpropmappingList;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (linkPropertyId != null ? linkPropertyId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Tbllinkproperties)) {
      return false;
    }
    Tbllinkproperties other = (Tbllinkproperties) object;
    if ((this.linkPropertyId == null && other.linkPropertyId != null) || (this.linkPropertyId != null && !this.linkPropertyId.equals(other.linkPropertyId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "org.createathon.blueinvestigate.di.entities.Tbllinkproperties[ linkPropertyId=" + linkPropertyId + " ]";
  }

}
