/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author aosama
 */
@Entity
@Table(name = "tbllinkpropmapping")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Tbllinkpropmapping.findAll", query = "SELECT t FROM Tbllinkpropmapping t")
  , @NamedQuery(name = "Tbllinkpropmapping.findByLinkPropMappingId", query = "SELECT t FROM Tbllinkpropmapping t WHERE t.linkPropMappingId = :linkPropMappingId")
  , @NamedQuery(name = "Tbllinkpropmapping.findByLinkID", query = "SELECT t FROM Tbllinkpropmapping t WHERE t.linkID = :linkID")
  , @NamedQuery(name = "Tbllinkpropmapping.findByDbFieldName", query = "SELECT t FROM Tbllinkpropmapping t WHERE t.dbFieldName = :dbFieldName")})
public class Tbllinkpropmapping implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "linkPropMappingId")
  private Integer linkPropMappingId;
  @Basic(optional = false)
  @Column(name = "LinkID")
  private int linkID;
  @Basic(optional = false)
  @Column(name = "dbFieldName")
  private String dbFieldName;
  @JoinColumn(name = "fromEntityPropId", referencedColumnName = "propertyId")
  @ManyToOne
  private Tblentityproperties fromEntityPropId;
  @JoinColumn(name = "linkMappingId", referencedColumnName = "mappingId")
  @ManyToOne(optional = false)
  private Tbllinkmapping linkMappingId;
  @JoinColumn(name = "propertyId", referencedColumnName = "linkPropertyId")
  @ManyToOne(optional = false)
  private Tbllinkproperties propertyId;
  @JoinColumn(name = "toEntityPropId", referencedColumnName = "propertyId")
  @ManyToOne
  private Tblentityproperties toEntityPropId;

  public Tbllinkpropmapping() {
  }

  public Tbllinkpropmapping(Integer linkPropMappingId) {
    this.linkPropMappingId = linkPropMappingId;
  }

  public Tbllinkpropmapping(Integer linkPropMappingId, int linkID, String dbFieldName) {
    this.linkPropMappingId = linkPropMappingId;
    this.linkID = linkID;
    this.dbFieldName = dbFieldName;
  }

  public Integer getLinkPropMappingId() {
    return linkPropMappingId;
  }

  public void setLinkPropMappingId(Integer linkPropMappingId) {
    this.linkPropMappingId = linkPropMappingId;
  }

  public int getLinkID() {
    return linkID;
  }

  public void setLinkID(int linkID) {
    this.linkID = linkID;
  }

  public String getDbFieldName() {
    return dbFieldName;
  }

  public void setDbFieldName(String dbFieldName) {
    this.dbFieldName = dbFieldName;
  }

  public Tblentityproperties getFromEntityPropId() {
    return fromEntityPropId;
  }

  public void setFromEntityPropId(Tblentityproperties fromEntityPropId) {
    this.fromEntityPropId = fromEntityPropId;
  }

  public Tbllinkmapping getLinkMappingId() {
    return linkMappingId;
  }

  public void setLinkMappingId(Tbllinkmapping linkMappingId) {
    this.linkMappingId = linkMappingId;
  }

  public Tbllinkproperties getPropertyId() {
    return propertyId;
  }

  public void setPropertyId(Tbllinkproperties propertyId) {
    this.propertyId = propertyId;
  }

  public Tblentityproperties getToEntityPropId() {
    return toEntityPropId;
  }

  public void setToEntityPropId(Tblentityproperties toEntityPropId) {
    this.toEntityPropId = toEntityPropId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (linkPropMappingId != null ? linkPropMappingId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Tbllinkpropmapping)) {
      return false;
    }
    Tbllinkpropmapping other = (Tbllinkpropmapping) object;
    if ((this.linkPropMappingId == null && other.linkPropMappingId != null) || (this.linkPropMappingId != null && !this.linkPropMappingId.equals(other.linkPropMappingId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "org.createathon.blueinvestigate.di.entities.Tbllinkpropmapping[ linkPropMappingId=" + linkPropMappingId + " ]";
  }

}
