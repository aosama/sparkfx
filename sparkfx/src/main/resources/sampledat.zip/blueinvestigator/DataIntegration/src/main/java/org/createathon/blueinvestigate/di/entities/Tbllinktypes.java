/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author aosama
 */
@Entity
@Table(name = "tbllinktypes")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Tbllinktypes.findAll", query = "SELECT t FROM Tbllinktypes t")
  , @NamedQuery(name = "Tbllinktypes.findByLinkId", query = "SELECT t FROM Tbllinktypes t WHERE t.linkId = :linkId")
  , @NamedQuery(name = "Tbllinktypes.findByLinkName", query = "SELECT t FROM Tbllinktypes t WHERE t.linkName = :linkName")
  , @NamedQuery(name = "Tbllinktypes.findByBidirectional", query = "SELECT t FROM Tbllinktypes t WHERE t.bidirectional = :bidirectional")})
public class Tbllinktypes implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "LinkId")
  private Integer linkId;
  @Basic(optional = false)
  @Column(name = "LinkName")
  private String linkName;
  @Basic(optional = false)
  @Column(name = "Bidirectional")
  private int bidirectional;
  @JoinColumn(name = "LinkFromEntity", referencedColumnName = "EntityId")
  @ManyToOne(optional = false)
  private Tblentitytypes linkFromEntity;
  @OneToMany(mappedBy = "parent")
  private List<Tbllinktypes> tbllinktypesList;
  @JoinColumn(name = "parent", referencedColumnName = "LinkId")
  @ManyToOne
  private Tbllinktypes parent;
  @JoinColumn(name = "LinkToEntity", referencedColumnName = "EntityId")
  @ManyToOne(optional = false)
  private Tblentitytypes linkToEntity;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "mappedLinkId")
  private List<Tbllinkmapping> tbllinkmappingList;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "linkId")
  private List<Tbllinkproperties> tbllinkpropertiesList;

  public Tbllinktypes() {
  }

  public Tbllinktypes(Integer linkId) {
    this.linkId = linkId;
  }

  public Tbllinktypes(Integer linkId, String linkName, int bidirectional) {
    this.linkId = linkId;
    this.linkName = linkName;
    this.bidirectional = bidirectional;
  }

  public Integer getLinkId() {
    return linkId;
  }

  public void setLinkId(Integer linkId) {
    this.linkId = linkId;
  }

  public String getLinkName() {
    return linkName;
  }

  public void setLinkName(String linkName) {
    this.linkName = linkName;
  }

  public int getBidirectional() {
    return bidirectional;
  }

  public void setBidirectional(int bidirectional) {
    this.bidirectional = bidirectional;
  }

  public Tblentitytypes getLinkFromEntity() {
    return linkFromEntity;
  }

  public void setLinkFromEntity(Tblentitytypes linkFromEntity) {
    this.linkFromEntity = linkFromEntity;
  }

  @XmlTransient
  public List<Tbllinktypes> getTbllinktypesList() {
    return tbllinktypesList;
  }

  public void setTbllinktypesList(List<Tbllinktypes> tbllinktypesList) {
    this.tbllinktypesList = tbllinktypesList;
  }

  public Tbllinktypes getParent() {
    return parent;
  }

  public void setParent(Tbllinktypes parent) {
    this.parent = parent;
  }

  public Tblentitytypes getLinkToEntity() {
    return linkToEntity;
  }

  public void setLinkToEntity(Tblentitytypes linkToEntity) {
    this.linkToEntity = linkToEntity;
  }

  @XmlTransient
  public List<Tbllinkmapping> getTbllinkmappingList() {
    return tbllinkmappingList;
  }

  public void setTbllinkmappingList(List<Tbllinkmapping> tbllinkmappingList) {
    this.tbllinkmappingList = tbllinkmappingList;
  }

  @XmlTransient
  public List<Tbllinkproperties> getTbllinkpropertiesList() {
    return tbllinkpropertiesList;
  }

  public void setTbllinkpropertiesList(List<Tbllinkproperties> tbllinkpropertiesList) {
    this.tbllinkpropertiesList = tbllinkpropertiesList;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (linkId != null ? linkId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Tbllinktypes)) {
      return false;
    }
    Tbllinktypes other = (Tbllinktypes) object;
    if ((this.linkId == null && other.linkId != null) || (this.linkId != null && !this.linkId.equals(other.linkId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "org.createathon.blueinvestigate.di.entities.Tbllinktypes[ linkId=" + linkId + " ]";
  }

}
