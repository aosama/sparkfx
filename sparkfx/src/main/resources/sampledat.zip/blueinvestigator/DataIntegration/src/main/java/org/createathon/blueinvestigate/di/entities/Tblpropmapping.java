/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author aosama
 */
@Entity
@Table(name = "tblpropmapping")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Tblpropmapping.findAll", query = "SELECT t FROM Tblpropmapping t")
  , @NamedQuery(name = "Tblpropmapping.findByPropMappingId", query = "SELECT t FROM Tblpropmapping t WHERE t.propMappingId = :propMappingId")
  , @NamedQuery(name = "Tblpropmapping.findByDbFieldName", query = "SELECT t FROM Tblpropmapping t WHERE t.dbFieldName = :dbFieldName")})
public class Tblpropmapping implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "propMappingId")
  private Integer propMappingId;
  @Basic(optional = false)
  @Column(name = "dbFieldName")
  private String dbFieldName;
  @JoinColumn(name = "propertyId", referencedColumnName = "propertyId")
  @ManyToOne(optional = false)
  private Tblentityproperties propertyId;
  @JoinColumn(name = "mappinId", referencedColumnName = "mappingId")
  @ManyToOne(optional = false)
  private Tbltablemappings mappinId;

  public Tblpropmapping() {
  }

  public Tblpropmapping(Integer propMappingId) {
    this.propMappingId = propMappingId;
  }

  public Tblpropmapping(Integer propMappingId, String dbFieldName) {
    this.propMappingId = propMappingId;
    this.dbFieldName = dbFieldName;
  }

  public Integer getPropMappingId() {
    return propMappingId;
  }

  public void setPropMappingId(Integer propMappingId) {
    this.propMappingId = propMappingId;
  }

  public String getDbFieldName() {
    return dbFieldName;
  }

  public void setDbFieldName(String dbFieldName) {
    this.dbFieldName = dbFieldName;
  }

  public Tblentityproperties getPropertyId() {
    return propertyId;
  }

  public void setPropertyId(Tblentityproperties propertyId) {
    this.propertyId = propertyId;
  }

  public Tbltablemappings getMappinId() {
    return mappinId;
  }

  public void setMappinId(Tbltablemappings mappinId) {
    this.mappinId = mappinId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (propMappingId != null ? propMappingId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Tblpropmapping)) {
      return false;
    }
    Tblpropmapping other = (Tblpropmapping) object;
    if ((this.propMappingId == null && other.propMappingId != null) || (this.propMappingId != null && !this.propMappingId.equals(other.propMappingId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "org.createathon.blueinvestigate.di.entities.Tblpropmapping[ propMappingId=" + propMappingId + " ]";
  }

}
