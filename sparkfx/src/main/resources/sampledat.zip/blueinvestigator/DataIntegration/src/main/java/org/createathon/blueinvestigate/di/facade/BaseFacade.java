package org.createathon.blueinvestigate.di.facade;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 *
 */
public class BaseFacade {

  protected EntityManager em;
  private static final EntityManagerFactory emf;

  static {
    emf = Persistence.createEntityManagerFactory("bluepu");
  }

  public BaseFacade() {
    this.em = emf.createEntityManager();
  }

}
