package org.createathon.blueinvestigate.di.facade;

import org.createathon.blueinvestigate.di.entities.Tblentitytypes;
import org.createathon.blueinvestigate.di.entities.Tbllinktypes;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.TypedQuery;

/**
 *
 * 
 */
public class FacadeEntityTypes extends BaseFacade
{

    public List<Tblentitytypes> findAll()
    {
        return em.createQuery("SELECT c FROM Tblentitytypes c", Tblentitytypes.class).getResultList();
    }

    public Tblentitytypes findEntityTypeByName(String entityName)
    {
        TypedQuery<Tblentitytypes> q = em.createQuery("SELECT c FROM Tblentitytypes c WHERE c.entityName=:entitynamex", Tblentitytypes.class);
        q.setParameter("entitynamex", entityName);
        if (!q.getResultList().isEmpty())
        {
            return q.getSingleResult();
        } else
        {
            String s = "Unkown entity " + entityName;
            Logger.getLogger(FacadeEntityTypes.class.getName()).log(Level.INFO, s);
            return null;
        }
    }

    public List<Tbllinktypes> findLinkTypesForEntity(String entityName)
    {
        Tblentitytypes entity = findEntityTypeByName(entityName);
        List<Tbllinktypes> lstLinkTypes = entity.getTbllinktypesList();
        lstLinkTypes.addAll(entity.getTbllinktypesList1());
        return lstLinkTypes;
    }

//    public List<Tbllinktypes> findLinkTypesForEntities(List<String> entityNames)
//    {
//        String items = "";
//
//        for (String s : entityNames)
//        {
//            items = items + "'" + s + "',";
//        }
//
//        items = items.substring(0, items.length() - 1);
//
//        TypedQuery<Tbllinktypes> q = em.createQuery("SELECT DISTINCT c FROM Tbllinktypes c WHERE c.linkFromEntity.entityName IN (:items)", Tbllinktypes.class);
//        q.setParameter("items", items);
//        return q.getResultList();
//    }
}
