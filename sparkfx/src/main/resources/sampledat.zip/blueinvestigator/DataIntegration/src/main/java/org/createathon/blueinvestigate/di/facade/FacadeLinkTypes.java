/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.di.facade;

import org.createathon.blueinvestigate.di.entities.Tbllinktypes;
import javax.persistence.TypedQuery;

/**
 *
 * 
 */
public class FacadeLinkTypes extends BaseFacade
{

    public Tbllinktypes findLinkTypeByName(String linkName) throws NoSuchFieldException, UnsupportedOperationException
    {
        TypedQuery<Tbllinktypes> q = em.createQuery("SELECT c FROM Tbllinktypes c WHERE c.linkName=:lname", Tbllinktypes.class);
        q.setParameter("lname", linkName);
        if (q.getResultList().isEmpty())
        {
            throw new NoSuchFieldException("Link not found");
        }
        if (q.getResultList().size() > 1)
        {
            throw new UnsupportedOperationException("multiple link types fond for " + linkName);
        }
        return q.getSingleResult();
    }

}
