package org.createathon.blueinvestigate.graph.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Ahmed Osama
 */
public class Entity
{

    private String type;
    private HashMap<String, Field> fields;
    private List<String> supportedLinkTypes;

    public List<String> getFieldNames()
    {
        List<String> lstFieldNames = new ArrayList<>();
        fields.keySet().forEach((String s) -> lstFieldNames.add(s));
        return lstFieldNames;
    }

    public List<String> getSupportedLinkTypes()
    {
        return supportedLinkTypes;
    }

    public void setSupportedLinkTypes(List<String> supportedLinkTypes)
    {
        this.supportedLinkTypes = supportedLinkTypes;
    }

    public void clearDBFieldNamesFromFields()
    {
        fields.entrySet().stream().forEach((entry) ->
        {
            entry.getValue().setDbFieldName(null);
        });
    }

    public HashMap<String, Field> getPrimaryKeyMap()
    {
        HashMap<String, Field> map = new HashMap<>();

        for (Map.Entry<String, Field> entry : fields.entrySet())
        {
            if (entry.getValue().getPrimaryKey() == 1)
            {
                map.put(entry.getKey(), entry.getValue());
            }
        }
        return map;
    }

    public boolean equalFields(HashMap<String, Field> m2)
    {
        if (fields.size() != m2.size())
        {
            return false;
        }
        for (String key : fields.keySet())
        {
            if (!fields.get(key).getValue().equals(m2.get(key).getValue()))
            {
                return false;
            }
        }
        return true;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public HashMap<String, Field> getFields()
    {
        return fields;
    }

    public void setFields(HashMap<String, Field> fields)
    {
        this.fields = fields;
    }

    public List<Field> getFieldsList()
    {
        List<Field> lst = new ArrayList<>();
        fields.entrySet().stream().forEach((entry) -> lst.add(entry.getValue()));
        return lst;
    }

}
