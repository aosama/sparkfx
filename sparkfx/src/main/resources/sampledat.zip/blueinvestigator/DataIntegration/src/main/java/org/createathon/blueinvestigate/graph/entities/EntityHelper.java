package org.createathon.blueinvestigate.graph.entities;

import org.createathon.blueinvestigate.di.entities.Tblentitytypes;
import org.createathon.blueinvestigate.di.facade.FacadeEntityTypes;

/**
 *
 * 
 */
public class EntityHelper
{

    FacadeEntityTypes facadeEntityTypes = new FacadeEntityTypes();

    public byte[] getIconForEntity(String entityName)
    {
        Tblentitytypes entityType = facadeEntityTypes.findEntityTypeByName(entityName);
        return entityType.getDefaultImage();
    }

}
