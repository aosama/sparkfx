package org.createathon.blueinvestigate.graph.entities;

import org.createathon.blueinvestigate.di.dbconnection.ConnectionFactory;
import org.createathon.blueinvestigate.di.entities.Tblentityproperties;
import org.createathon.blueinvestigate.di.entities.Tblentitytypes;
import org.createathon.blueinvestigate.di.entities.Tbllinktypes;
import org.createathon.blueinvestigate.di.entities.Tblpropmapping;
import org.createathon.blueinvestigate.di.entities.Tbltablemappings;
import org.createathon.blueinvestigate.di.facade.FacadeEntityTypes;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * 
 */
public class EntityReader
{

    private final ConnectionFactory connectionFactory = new ConnectionFactory();
    private final FacadeEntityTypes facadeEntityTypes = new FacadeEntityTypes();

    public Entity findEntity(String entityTypeAsString, HashMap<String, Field> primaryKey) throws SQLException, NullPointerException
    {
        if (primaryKey == null)
        {
            throw new NullPointerException("Primary Key Was Null");
        }
        Tblentitytypes entityType = facadeEntityTypes.findEntityTypeByName(entityTypeAsString);

        List<Tbltablemappings> lstTableMappings = connectionFactory.findTableMappingsForEntity(entityTypeAsString);

        Entity entity = new Entity();

        for (Tbltablemappings tm : lstTableMappings)
        {
            Connection conn = connectionFactory.getConnectionForEntityMapping(tm);

            //create the sql select statement
            String sqlText = "SELECT * FROM " + tm.getMappedTableName() + " ";

            //Get Where Condition
            sqlText = sqlText + createConditionForEntityQuery(primaryKey, tm);

            //Return Graph Entity
            entity = loadEntity(entity, entityType, tm, sqlText, conn);

            conn.close();
        }

        //IF CONDITION TO CHECK IF ENTITY NOT FOUND
        //throw new Exception("Enttiy not found");
        //have to clear DB field names for entity fields before returning it
        //or else we have crashes while expanding links for an entity
        entity.clearDBFieldNamesFromFields();
        entity.setSupportedLinkTypes(findSupportedLinkTypes(entity.getType()));
        return entity;
    }

    private String createConditionForEntityQuery(HashMap<String, Field> primaryKey, Tbltablemappings tableMapping)
    {

        primaryKey = populatePkDBFieldNames(primaryKey, tableMapping);

        String condition = " WHERE ";
        if (primaryKey.size() > 1)
        {
            condition = condition + "(";
        }

        for (Map.Entry<String, Field> entry : primaryKey.entrySet())
        {
            if (entry.getValue().getDataType().equalsIgnoreCase("string"))
            {
                condition = condition + entry.getValue().getDbFieldName() + "='" + entry.getValue().getValue().toString() + "' AND";
            } else
            {
                condition = condition + entry.getValue().getDbFieldName() + "=" + entry.getValue().getValue().toString() + " AND";
            }
        }
        condition = condition.substring(0, condition.length() - 3);
        if (primaryKey.size() > 1)
        {
            condition = condition + ")";
        }

        return condition;
    }

    private Entity loadEntity(Entity entity, Tblentitytypes entityType, Tbltablemappings entityMapping, String sqlText, Connection connection) throws SQLException
    {

        entity.setType(entityType.getEntityName());

        List<Tblpropmapping> lstPropMappingList = entityMapping.getTblpropmappingList();

        HashMap<String, Field> fieldsMap = new HashMap<>();

        Statement statement = connection.createStatement();
        ResultSet rs = statement.executeQuery(sqlText);

        rs.next();

        for (Tblpropmapping prop : lstPropMappingList)
        {
            Field field = new Field();
            field.setDataType(prop.getPropertyId().getPropType());
            field.setIsLabel(prop.getPropertyId().getLabel());
            field.setPrimaryKey(prop.getPropertyId().getPrimaryKey());
            field.setBlueParentEntityType(entityType.getEntityName());
            try
            {
                field.setValue(rs.getString(prop.getDbFieldName()));
            } catch (Exception e)
            {
                System.out.println("dummy line");
                e.printStackTrace();
            }

            field.setDbFieldName(prop.getDbFieldName());
            field.setBlueFieldName(prop.getPropertyId().getPropName());
            fieldsMap.put(prop.getPropertyId().getPropName(), field);
        }

        entity.setFields(fieldsMap);
        return entity;
    }

    public HashMap<String, Field> getBlankPrimaryKeyMapForEntity(Tblentitytypes entityType)
    {
        return getBlankPrimaryKeyMapForEntity(entityType.getEntityName());
    }

    public HashMap<String, Field> getBlankPrimaryKeyMapForEntity(String entityName)
    {
        Tblentitytypes entityType = facadeEntityTypes.findEntityTypeByName(entityName);
        HashMap<String, Field> primaryKeyMap = new HashMap<>();

        for (Tblentityproperties prop : entityType.getTblentitypropertiesList())
        {
            if (prop.getPrimaryKey() == 1)
            {
                Field pk = new Field();

                pk.setDataType(prop.getPropType());
                pk.setBlueFieldName(prop.getPropName());
                pk.setIsLabel(prop.getLabel());
                //pk.setDbFieldName(propMapping.getDbFieldName());
                pk.setPrimaryKey(prop.getPrimaryKey());

                primaryKeyMap.put(pk.getBlueFieldName(), pk);
            }
        }
        return primaryKeyMap;
    }

    public HashMap<String, Field> populatePkDBFieldNames(HashMap<String, Field> primaryKey, Tbltablemappings tableMapping) throws NoSuchFieldError
    {
        int found = 0;
        for (Tblpropmapping propMapping : tableMapping.getTblpropmappingList())
        {
            if (primaryKey.containsKey(propMapping.getPropertyId().getPropName()) == true)
            {
                String dbFieldName = findDBFieldNameFromTableMapping(propMapping.getPropertyId().getPropName(), tableMapping);
                Field field = primaryKey.get(propMapping.getPropertyId().getPropName());
                field.setDbFieldName(dbFieldName);
                primaryKey.put(field.getBlueFieldName(), field);
                found = 1;
            }
        }
        if (found == 0)
        {
            throw new NoSuchFieldError("couldnt find primary key mapping for mapping id " + tableMapping.getMappingId());
        }
        return primaryKey;
    }

    private String findDBFieldNameFromTableMapping(String blueFieldName, Tbltablemappings tableMapping) throws NoSuchFieldError
    {
        for (Tblpropmapping propMapping : tableMapping.getTblpropmappingList())
        {
            if (propMapping.getPropertyId().getPropName().equalsIgnoreCase(blueFieldName))
            {
                return propMapping.getDbFieldName();
            }
        }
        throw new NoSuchFieldError(blueFieldName + " was not found in table mapping " + tableMapping.getMappingId());
    }

    public List<String> findSupportedLinkTypes(String entityName)
    {
        List<String> supportedLinkTypesList = new ArrayList<>();
        Tblentitytypes entityType = facadeEntityTypes.findEntityTypeByName(entityName);

        List<Tbllinktypes> tbllinktypesList = entityType.getTbllinktypesList();
        for (Tbllinktypes linkType : tbllinktypesList)
        {
            if (supportedLinkTypesList.contains(linkType.getLinkName()) == false)
            {
                supportedLinkTypesList.add(linkType.getLinkName());
            }
        }

        tbllinktypesList = entityType.getTbllinktypesList1();
        for (Tbllinktypes linkType : tbllinktypesList)
        {
            if (supportedLinkTypesList.contains(linkType.getLinkName()) == false)
            {
                supportedLinkTypesList.add(linkType.getLinkName());
            }
        }

        return supportedLinkTypesList;
    }

    public List<String> findLinkTypes(List<String> entityNames)
    {
        List<String> linkTypes = new ArrayList<>();

        entityNames.forEach((entityName) ->
        {
            List<String> supportedLinkTypes = findSupportedLinkTypes(entityName);
            supportedLinkTypes.forEach((e) ->
            {
                if (linkTypes.contains(e) == false)
                {
                    linkTypes.add(e);
                }
            });
        });

        return linkTypes;
    }

    public boolean doesEntitySupportThisLink(String entityType, String linkType)
    {
        Tblentitytypes entity = facadeEntityTypes.findEntityTypeByName(entityType);

        for (Tbllinktypes lt : entity.getTbllinktypesList())
        {
            if (lt.getLinkName().equalsIgnoreCase(linkType))
            {
                return true;
            }
        }

        for (Tbllinktypes lt : entity.getTbllinktypesList1())
        {
            if (lt.getLinkName().equalsIgnoreCase(linkType))
            {
                return true;
            }
        }

        return false;
    }

}
