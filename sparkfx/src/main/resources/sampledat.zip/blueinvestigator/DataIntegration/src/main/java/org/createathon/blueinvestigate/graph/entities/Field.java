package org.createathon.blueinvestigate.graph.entities;

/**
 *
 * @author Ahmed Osama
 */
public class Field
{

    private String dataType;
    private Object dataTypeAsObject;
    private Object value;
    private int primaryKey;
    private int isLabel;
    private String dbFieldName;
    private String blueFieldName;
    private String blueFromEntityFieldName;
    private String blueToEntityFieldName;
    private String blueParentEntityType;

    public String getBlueFieldName()
    {
        return blueFieldName;
    }

    public void setBlueFieldName(String blueFieldName)
    {
        this.blueFieldName = blueFieldName;
    }

    public String getDbFieldName()
    {
        return dbFieldName;
    }

    public void setDbFieldName(String dbFieldName)
    {
        this.dbFieldName = dbFieldName;
    }

    public int getIsLabel()
    {
        return isLabel;
    }

    public void setIsLabel(int isLabel)
    {
        this.isLabel = isLabel;
    }

    public int getPrimaryKey()
    {
        return primaryKey;
    }

    public void setPrimaryKey(int primaryKey)
    {
        this.primaryKey = primaryKey;
    }

    public String getDataType()
    {
        return dataType;
    }

    public void setDataType(String dataType)
    {
        this.dataType = dataType;
    }

    public Object getDataTypeAsObject()
    {
        return dataTypeAsObject;
    }

    public void setDataTypeAsObject(Object dataTypeAsObject)
    {
        this.dataTypeAsObject = dataTypeAsObject;
    }

    public Object getValue()
    {
        return value;
    }

    public void setValue(Object value)
    {
        this.value = value;
    }

    public String getBlueFromEntityFieldName()
    {
        return blueFromEntityFieldName;
    }

    public void setBlueFromEntityFieldName(String blueFromEntityFieldName)
    {
        this.blueFromEntityFieldName = blueFromEntityFieldName;
    }

    public String getBlueToEntityFieldName()
    {
        return blueToEntityFieldName;
    }

    public void setBlueToEntityFieldName(String blueToEntityFieldName)
    {
        this.blueToEntityFieldName = blueToEntityFieldName;
    }

    public String getBlueParentEntityType()
    {
        return blueParentEntityType;
    }

    public void setBlueParentEntityType(String blueParentEntityType)
    {
        this.blueParentEntityType = blueParentEntityType;
    }

}
