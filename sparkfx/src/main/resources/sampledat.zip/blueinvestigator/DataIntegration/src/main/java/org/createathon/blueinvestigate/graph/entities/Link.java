package org.createathon.blueinvestigate.graph.entities;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Ahmed Osama
 */
public class Link {

  private Integer blueLinkId;
  private String linkName;
  private Integer blueLinkParentId;
  private Integer bidirectional;
  private String fromEntityType;
  private String toEntityType;
  private Entity fromEntityValue;
  private Entity toEntityValue;
  private HashMap<String, Field> linkData;
  private Integer dataSourceMappingId;

  public HashMap<String, Field> getPrimaryKeyMap() {
    HashMap<String, Field> tempMap = new HashMap<>();
    linkData.entrySet()
            .parallelStream()
            .filter(f -> f.getValue().getPrimaryKey() == 1)
            .map(f -> tempMap.put(f.getKey(), f.getValue()));
    return tempMap;
  }

  public boolean equalFields(HashMap<String, Field> m2) {
    if (linkData.size() != m2.size()) {
      return false;
    }

    for (String key : linkData.keySet()) {
      if (linkData.get(key).getValue() != null) {
        if (m2.get(key) != null) {
          if (!linkData.get(key).getValue().equals(m2.get(key).getValue())) {
            return false;
          }
        } else {
          System.out.println(key + " was not found in target link while comparison");
        }

      } else {
        System.out.println(key + " had a null value in source link");
      }

    }
    return true;
  }

  public HashMap<String, Field> findFromEntityFields() {
    HashMap<String, Field> fromEntityFields = new HashMap<>();

    for (Map.Entry<String, Field> field : this.linkData.entrySet()) {
      if (field.getValue().getBlueFromEntityFieldName() != null) {
        fromEntityFields.put(field.getKey(), field.getValue());
      }
    }
    return fromEntityFields;
  }

  public HashMap<String, Field> findToEntityFields() {
    HashMap<String, Field> fromEntityFields = new HashMap<>();

    for (Map.Entry<String, Field> field : this.linkData.entrySet()) {
      if (field.getValue().getBlueToEntityFieldName() != null) {
        fromEntityFields.put(field.getKey(), field.getValue());
      }
    }
    return fromEntityFields;
  }

  public Field findFieldByGalmdringPropertyName(String bluePropertyName) throws Exception {
    if (linkData.containsKey(bluePropertyName)) {
      return linkData.get(bluePropertyName);
    } else {
      throw new Exception("blue property name not found");
    }
  }

  public HashMap<String, Field> getLinkData() {
    return linkData;
  }

  public void setLinkData(HashMap<String, Field> linkData) {
    this.linkData = linkData;
  }

  public String getFromEntityType() {
    return fromEntityType;
  }

  public void setFromEntityType(String fromEntityType) {
    this.fromEntityType = fromEntityType;
  }

  public String getToEntityType() {
    return toEntityType;
  }

  public void setToEntityType(String toEntityType) {
    this.toEntityType = toEntityType;
  }

  public Integer getBidirectional() {
    return bidirectional;
  }

  public void setBidirectional(Integer bidirectional) {
    this.bidirectional = bidirectional;
  }

  public Integer getBlueLinkId() {
    return blueLinkId;
  }

  public void setBlueLinkId(Integer blueLinkId) {
    this.blueLinkId = blueLinkId;
  }

  public Integer getBlueLinkParentId() {
    return blueLinkParentId;
  }

  public void setBlueLinkParentId(Integer blueLinkParentId) {
    this.blueLinkParentId = blueLinkParentId;
  }

  public String getLinkName() {
    return linkName;
  }

  public void setLinkName(String linkName) {
    this.linkName = linkName;
  }

  public Integer getDataSourceMappingId() {
    return dataSourceMappingId;
  }

  public void setDataSourceMappingId(Integer dataSourceMappingId) {
    this.dataSourceMappingId = dataSourceMappingId;
  }

  public void setFromEntityValue(Entity fromEntityValue) {
    this.fromEntityValue = fromEntityValue;
  }

  public Entity getFromEntityValue() {
    return fromEntityValue;
  }

  public Entity getToEntityValue() {
    return toEntityValue;
  }

  public void setToEntityValue(Entity toEntityValue) {
    this.toEntityValue = toEntityValue;
  }

}
