/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.createathon.blueinvestigate.graph.entities;

import org.createathon.blueinvestigate.di.dbconnection.ConnectionFactory;
import org.createathon.blueinvestigate.di.entities.Tbldatasources;
import org.createathon.blueinvestigate.di.entities.Tbllinkmapping;
import org.createathon.blueinvestigate.di.entities.Tbllinkpropmapping;
import org.createathon.blueinvestigate.di.entities.Tbllinktypes;
import org.createathon.blueinvestigate.di.facade.FacadeLinkTypes;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 */
public class LinkReader
{

    private final ConnectionFactory connectionFactory = new ConnectionFactory();
    private final FacadeLinkTypes facadeLinkTypes = new FacadeLinkTypes();
    private final LinkReaderHelper linkReaderHelper = new LinkReaderHelper();

    public List<Link> expandLinksForEntity(Entity entity, String linkTypeName) throws ClassNotFoundException, NoSuchFieldException, SQLException
    {
        Tbllinktypes linkType = facadeLinkTypes.findLinkTypeByName(linkTypeName);

        List<Link> lstLinks = new ArrayList<>();
        for (Tbllinkmapping linkMapping : linkType.getTbllinkmappingList())
        {
            Tbldatasources ds = linkMapping.getMappedDataSourceId();
            Connection connection = connectionFactory.getConnectionFromDataSource(ds);

            String sqlText = linkReaderHelper.createSelectForLinkFromEntity(linkMapping, linkType, entity.getPrimaryKeyMap(), entity.getType());

            List<Link> loadLinks = null;
            try
            {
                loadLinks = loadLinks(sqlText, linkType, connection, linkMapping);
            } catch (SQLException ex)
            {
                System.out.println("==============================================================");
                System.out.println("Error while Loading Links ");
                System.out.println("Query Was: " + sqlText);
                System.out.println("Link Type Was: " + linkType.getLinkName());
                System.out.println("Link Mapping ID Was: " + linkMapping.getMappingId());
                System.out.println("Enity Type Was: " + entity.getType());
                System.out.println("==============================================================");
                Logger.getLogger(LinkReader.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (loadLinks != null)
            {
                lstLinks.addAll(loadLinks);
            }
            connection.close();
        }

        return lstLinks;

    }

    private List<Link> loadLinks(String sqlText, Tbllinktypes linkType, Connection connection, Tbllinkmapping linkMapping) throws SQLException, ClassNotFoundException
    {
        List<Link> foundLinks = new ArrayList<>();

        ResultSet rs;

        Statement statement = connection.createStatement();
        rs = statement.executeQuery(sqlText);

        if (rs == null)
        {
            return null;
        }

        while (rs.next())
        {
            Link link = new Link();

            link.setBidirectional(linkType.getBidirectional());
            link.setFromEntityType(linkType.getLinkFromEntity().getEntityName());
            link.setBlueLinkId(linkType.getLinkId());
            if (linkType.getParent() != null)
            {
                link.setBlueLinkParentId(linkType.getParent().getLinkId());
            }
            link.setLinkName(linkType.getLinkName());
            link.setToEntityType(linkType.getLinkToEntity().getEntityName());
            link.setDataSourceMappingId(linkMapping.getMappingId());

            HashMap<String, Field> fieldsMap = new HashMap<>();

            for (Tbllinkpropmapping prop : linkMapping.getTbllinkpropmappingList())
            {
                Field field = new Field();

                field.setDataType(prop.getPropertyId().getPropertyDataType());
                field.setIsLabel(prop.getPropertyId().getLabel());
                field.setPrimaryKey(prop.getPropertyId().getPrimaryKey());
                field.setValue(rs.getString(prop.getDbFieldName()));
                field.setDbFieldName(prop.getDbFieldName());
                field.setBlueFieldName(prop.getPropertyId().getPropertyName());

                if (prop.getFromEntityPropId() != null)
                {
                    field.setBlueFromEntityFieldName(prop.getFromEntityPropId().getPropName());
                }

                if (prop.getToEntityPropId() != null)
                {
                    field.setBlueToEntityFieldName(prop.getToEntityPropId().getPropName());
                }

                fieldsMap.put(prop.getPropertyId().getPropertyName(), field);
            }

            link.setLinkData(fieldsMap);

            //GET Entity A
            Entity fromEntityFromLink = linkReaderHelper.getFromEntityFromLink(linkType, link);
            link.setFromEntityValue(fromEntityFromLink);

            //GET Entity B
            Entity toEntityFromLink = linkReaderHelper.getToEntityFromLink(linkType, link);
            link.setToEntityValue(toEntityFromLink);

            foundLinks.add(link);
        }

        return foundLinks;
    }

}
