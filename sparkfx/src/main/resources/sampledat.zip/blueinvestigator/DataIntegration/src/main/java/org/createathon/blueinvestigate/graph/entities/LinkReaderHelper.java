package org.createathon.blueinvestigate.graph.entities;

import org.createathon.blueinvestigate.di.entities.Tblentitytypes;
import org.createathon.blueinvestigate.di.entities.Tbllinkmapping;
import org.createathon.blueinvestigate.di.entities.Tbllinkpropmapping;
import org.createathon.blueinvestigate.di.entities.Tbllinktypes;
import org.createathon.blueinvestigate.di.facade.FacadeEntityTypes;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class LinkReaderHelper
{

    EntityReader entityReader = new EntityReader();
    FacadeEntityTypes facadeEntityTypes = new FacadeEntityTypes();

    public String createSelectForLinkFromEntity(Tbllinkmapping linkMapping, Tbllinktypes linkType, HashMap<String, Field> entityPk, String entityTypeName)
    {
        String sqlText = "SELECT * FROM " + linkMapping.getMappedTableName();

        String whereCondition = createConditionForQuery(entityPk, linkMapping, entityTypeName);

        return sqlText + whereCondition;
    }

    public String createConditionForQuery(HashMap<String, Field> entityPrimaryKey, Tbllinkmapping linkMapping, String entityTypeName)
    {
        HashMap<String, Field> primaryKey = null;
        if (linkMapping.getMappedLinkId().getLinkFromEntity().getEntityName().equalsIgnoreCase(entityTypeName))
        {
            primaryKey = populateFromEntityPkDBFieldNames(entityPrimaryKey, linkMapping);
        } else if (linkMapping.getMappedLinkId().getLinkToEntity().getEntityName().equalsIgnoreCase(entityTypeName))
        {
            primaryKey = populateToEntityPkDBFieldNames(entityPrimaryKey, linkMapping);
        }

        if (primaryKey == null)
        {
            throw new NullPointerException("Null primary key during creation of condition for link where entity type " + entityTypeName);
        }

        String condition = " WHERE ";
        if (primaryKey.size() > 1)
        {
            condition = condition + "(";
        }

        for (Map.Entry<String, Field> entry : primaryKey.entrySet())
        {
            if (entry.getValue().getDataType().equalsIgnoreCase("string"))
            {
                condition = condition + entry.getValue().getDbFieldName() + "='" + entry.getValue().getValue().toString() + "' AND";
            } else
            {
                condition = condition + entry.getValue().getDbFieldName() + "=" + entry.getValue().getValue().toString() + " AND";
            }
        }
        condition = condition.substring(0, condition.length() - 3);
        if (primaryKey.size() > 1)
        {
            condition = condition + ")";
        }

        return condition;
    }

    public HashMap<String, Field> populateFromEntityPkDBFieldNames(HashMap<String, Field> primaryKey, Tbllinkmapping linkMapping)
    {
        for (Tbllinkpropmapping propMapping : linkMapping.getTbllinkpropmappingList())
        {
            if (propMapping.getFromEntityPropId() != null)
            {
                Field pkField = primaryKey.get(propMapping.getFromEntityPropId().getPropName());

                pkField.setDbFieldName(propMapping.getDbFieldName());
                primaryKey.put(propMapping.getFromEntityPropId().getPropName(), pkField);
            }
        }
        return primaryKey;
    }

    public HashMap<String, Field> populateToEntityPkDBFieldNames(HashMap<String, Field> primaryKey, Tbllinkmapping linkMapping)
    {
        for (Tbllinkpropmapping propMapping : linkMapping.getTbllinkpropmappingList())
        {
            if (propMapping.getToEntityPropId() != null)
            {
                Field pkField = primaryKey.get(propMapping.getToEntityPropId().getPropName());
                pkField.setDbFieldName(propMapping.getDbFieldName());
                primaryKey.put(propMapping.getToEntityPropId().getPropName(), pkField);
            }
        }
        return primaryKey;

//        for (Map.Entry<String, Field> pkEntry : primaryKey.entrySet())
//        {
//            for (Tbllinkpropmapping propMapping : linkMapping.getTbllinkpropmappingList())
//            {
//                if (propMapping.getPropertyId().getPropertyName().equalsIgnoreCase(pkEntry.getKey()))
//                {
//                    Field pkField = primaryKey.get(propMapping.getPropertyId().getPropertyName());
//
//                    pkField.setDbFieldName(propMapping.getDbFieldName());
//                    primaryKey.put(propMapping.getPropertyId().getPropertyName(), pkField);
//                }
//            }
//        }
//        for (Tbllinkpropmapping propMapping : linkMapping.getTbllinkpropmappingList())
//        {
//            if (propMapping.getTbllinktoentitypropmapping() != null)
//            {
//                Field pkField = primaryKey.get(propMapping.getTbllinktoentitypropmapping().getToEntityPropId().getPropName());
//
//                pkField.setDbFieldName(propMapping.getDbFieldName());
//                primaryKey.put(propMapping.getTbllinktoentitypropmapping().getToEntityPropId().getPropName(), pkField);
//            }
//        }
    }

    public Entity getFromEntityFromLink(Tbllinktypes linkType, Link link) throws ClassNotFoundException, SQLException
    {
        Tblentitytypes fromEntity = linkType.getLinkFromEntity();

        HashMap<String, Field> pkForEntity = entityReader.getBlankPrimaryKeyMapForEntity(fromEntity);

        HashMap<String, Field> fromEntityFields = link.findFromEntityFields();

        for (Map.Entry<String, Field> pkForEntityEntry : pkForEntity.entrySet())
        {
            for (Map.Entry<String, Field> fromEntityFieldsEntry : fromEntityFields.entrySet())
            {
                if (pkForEntityEntry.getValue().getBlueFieldName().equals(fromEntityFieldsEntry.getValue().getBlueFromEntityFieldName()))
                {
                    Field fieldValue = pkForEntityEntry.getValue();
                    fieldValue.setValue(fromEntityFieldsEntry.getValue().getValue());
                    pkForEntity.put(fieldValue.getBlueFieldName(), fieldValue);
                }
            }
        }

        Entity entity = entityReader.findEntity(linkType.getLinkFromEntity().getEntityName(), pkForEntity);

        return entity;
    }

    public Entity getToEntityFromLink(Tbllinktypes linkType, Link link) throws ClassNotFoundException, SQLException
    {
        Tblentitytypes toEntity = linkType.getLinkToEntity();

        HashMap<String, Field> pkForEntity = entityReader.getBlankPrimaryKeyMapForEntity(toEntity);

        HashMap<String, Field> toEntityFields = link.findToEntityFields();

        for (Map.Entry<String, Field> pkForEntityEntry : pkForEntity.entrySet())
        {
            for (Map.Entry<String, Field> toEntityFieldsEntry : toEntityFields.entrySet())
            {
                if (pkForEntityEntry.getValue().getBlueFieldName().equals(toEntityFieldsEntry.getValue().getBlueToEntityFieldName()))
                {
                    Field fieldValue = pkForEntityEntry.getValue();
                    fieldValue.setValue(toEntityFieldsEntry.getValue().getValue());
                    pkForEntity.put(fieldValue.getBlueFieldName(), fieldValue);
                }
            }
        }

        Entity entity = entityReader.findEntity(linkType.getLinkToEntity().getEntityName(), pkForEntity);

        return entity;
    }
}
