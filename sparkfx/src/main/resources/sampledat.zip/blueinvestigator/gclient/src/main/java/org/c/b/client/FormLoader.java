/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.c.b.client;

import org.c.b.client.interfaces.IFXDialog;
import org.c.b.client.forms.expandentity.FrmExpandEntityController;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

/**
 *
 * @author aosama
 */
public class FormLoader
{

    public static Parent createView(Class clazz)
    {
        String fxmlName = clazz.getSimpleName().replace("Controller", "") + ".fxml";
        Parent root = null;

        try
        {
            FXMLLoader myLoader = new FXMLLoader(clazz.getResource(fxmlName));
            root = myLoader.load();
        } catch (IOException ex)
        {
            Logger.getLogger(FormLoader.class.getName()).log(Level.INFO, "message", ex);
        }
        return root;
    }

    public static Object showDialog(Class clazz, Object dlgData)
    {
        String clazzName = clazz.getSimpleName();
        String fxmlName = clazzName.replace("Controller", "") + ".fxml";

        try
        {
            FXMLLoader myLoader = new FXMLLoader(clazz.getResource(fxmlName));
            Parent rootNode = myLoader.load();
            IFXDialog controller = myLoader.<FrmExpandEntityController>getController();

            controller.initializeDialogData(dlgData);

            controller.showDialog(rootNode);
            return controller;
        } catch (IOException ex)
        {
            Logger.getLogger(FormLoader.class.getName()).log(Level.INFO, "message", ex);
        }
        return null;
    }
}
