package org.c.b.client.analysis;

import org.c.b.client.forms.graph.FrmGraphController;
import org.c.b.client.graphstyles.BlueNodeStyles;
import com.yworks.yfiles.graph.IEdge;
import com.yworks.yfiles.graph.IGraph;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.utils.IListEnumerable;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.createathon.blueinvestigate.graph.entities.Entity;
import org.createathon.blueinvestigate.graph.entities.EntityReader;
import org.createathon.blueinvestigate.graph.entities.Field;
import org.createathon.blueinvestigate.graph.entities.Link;
import org.createathon.blueinvestigate.graph.entities.LinkReader;

/**
 *
 * @author aosama
 */
public class GraphAnalysis {

  private final IGraph graph;
  private final FrmGraphController frmGraph;
  private final EntityReader entityReader = new EntityReader();

  public GraphAnalysis(IGraph graph, FrmGraphController frmGraph) {
    this.graph = graph;
    this.frmGraph = frmGraph;
  }

  public List<Entity> getAllEntities() {
    List<Entity> lstEntities = graph.getNodes().stream()
            .filter(e -> e.getTag() != null)
            .map(e -> (Entity) e.getTag())
            .collect(Collectors.toList());
    return lstEntities;
  }

  public void loadEntity(HashMap<String, Field> primaryKey, String entityType) throws NullPointerException, SQLException {
    Entity entity = entityReader.findEntity(entityType, primaryKey);
    findNodeByEntityOrAdd(entity);
  }

  /**
   *
   * This method take a list of entities and expands all supported link types
   *
   * @param lstEntities - a list of selected entities in the graph view
   */
  public void expandLinksforEntities(List<Entity> lstEntities) {
    lstEntities.forEach((entity)
            -> {
      entity.getSupportedLinkTypes().forEach((s) -> expandLinkForEntity(entity, s));
    });

  }

  public void expandLinkForEntity(Entity entity, String linkTypeString) {
    LinkReader linkReader = new LinkReader();
    INode node = findNodeByEntity(entity);
    List<Link> links = null;
    try {
      links = linkReader.expandLinksForEntity(entity, linkTypeString);
    } catch (ClassNotFoundException | NoSuchFieldException | SQLException ex) {
      Logger.getLogger(GraphAnalysis.class.getName()).log(Level.SEVERE, null, ex);
    }
    links.forEach((link)
            -> {
      //createEdgesAndTargetNode(node, link);
      if (link.getFromEntityType().equals(entity.getType())) {
        createEdgesAndTargetNode(node, link);
      } else {
        //create from node then create link
        //INode newFromEntityNode = findNodeByEntity(link.getFromEntityValue());

        INode newSourceNode = findNodeByEntityOrAdd(link.getFromEntityValue());
        createEdgesAndTargetNode(newSourceNode, link);
      }
    });
  }

  public void loadCellPhone(String cellPhoneNumber) throws Exception {

    HashMap<String, Field> pkMap = entityReader.getBlankPrimaryKeyMapForEntity("mobile");

    Field entry = pkMap.get("cellnumber");
    entry.setValue(cellPhoneNumber);
    pkMap.put("cellnumber", entry);

    Entity primaryPhoneEntity = entityReader.findEntity("mobile", pkMap);
    if (primaryPhoneEntity == null) {
      throw new Exception("cell phone not found");
    }

    INode primaryPhoneNode = findNodeByEntityOrAdd(primaryPhoneEntity);

    LinkReader linkReader = new LinkReader();

    List<Link> outGoingCallsLinksList = linkReader.expandLinksForEntity(primaryPhoneEntity, "Outbound Mobile Call");
    outGoingCallsLinksList.forEach((link) -> createEdgesAndTargetNode(primaryPhoneNode, link));

    List<Link> ownersList = linkReader.expandLinksForEntity(primaryPhoneEntity, "Cell Phone Ownership");
    //ownersList.forEach((link) -> addLink(primaryPhoneNode, link));

    for (Link ln : ownersList) {
      INode addEntityNode = findNodeByEntityOrAdd(ln.getFromEntityValue());
      IEdge edgex = graph.createEdge(addEntityNode, primaryPhoneNode);
      edgex.setTag(ln);
    }
  }

  private void createEdgesAndTargetNode(INode soureNode, Link l) {
    //INode toNode = createEntityNode(l.getToEntityValue());
    INode toNode = findNodeByEntityOrAdd(l.getToEntityValue());
    findEdgeOrCreate(soureNode, toNode, l);
    //createEdge(soureNode, toNode, l);
  }

  private INode createEntityNode(Entity entity) {
    INode node = graph.createNode(BlueNodeStyles.
            getRectangleForDefaultNodeStyle(entity.getType()),
            BlueNodeStyles.getDefaultNodeStyle(entity.getType()));
    node.setTag(entity);
    graph.addLabel(node, getLabelStringFromEntity(entity));
    return node;
  }

  private IEdge createEdge(INode sourceNode, INode targetNode, Link tag) {
    IEdge edge = graph.createEdge(sourceNode, targetNode);
    edge.setTag(tag);
    return edge;
  }

  private IEdge findEdgeOrCreate(INode sourceNode, INode targetNode, Link link) {
    List<IEdge> foundEdgesList = graph.getEdges()
            .stream()
            .filter(e -> e.getTag() != null)
            .filter(e -> ((Link) e.getTag()).getLinkName().equals(link.getLinkName()))
            .filter(e -> ((Link) e.getTag()).equalFields(link.getLinkData()))
            .collect(Collectors.toList());

    if (foundEdgesList.size() > 1) {
      Logger.getLogger(GraphAnalysis.class.getName()).log(Level.SEVERE, "While searching for an edge multiple results were found");
      return null;
    }

    if (foundEdgesList.isEmpty()) {
      IEdge createEdge = createEdge(sourceNode, targetNode, link);
      return createEdge;
    }

    return foundEdgesList.get(0);
  }

  private String getLabelStringFromEntity(Entity entity) {
    String label = entity.getFieldsList().stream()
            .filter(e -> e.getIsLabel() == 1)
            .map(e -> e.getValue().toString())
            .reduce((t, u) -> t + " " + u)
            .get();
    return label;
  }

  public INode findNodeByEntityOrAdd(Entity entity) {
    INode tmpNode = findNodeByEntity(entity);
    if (tmpNode == null) {
      return createEntityNode(entity);
    } else {
      return tmpNode;
    }
  }

  public INode findNodeByEntity(Entity entity) {
    IListEnumerable<INode> allNodes = graph.getNodes();

    List<INode> nodes;
    nodes = allNodes.parallelStream()
            .filter(n -> n.getTag() != null)
            .filter(node -> ((Entity) node.getTag()).getType().equals(entity.getType()))
            .filter(node -> ((Entity) node.getTag()).equalFields(entity.getFields()))
            .collect(Collectors.toList());

    if (nodes.size() > 1) {
      Logger.getLogger(GraphAnalysis.class.getName()).log(Level.INFO, "{0}, error , while searching for a node in the graph found more than one result", getClass().getCanonicalName());
    }

    if (nodes.isEmpty()) {
      return null;
    }

    return nodes.get(0);
  }

  public void clearGraph() {
    graph.clear();
  }

  public Long countEntityType(String entityType) {
    List<Entity> allEntities = getAllEntities();
    return allEntities.stream()
            .filter(e -> e.getType().equals(entityType))
            .count();
  }

  /**
   * will return a list of string containing a unique list of types of entities
   * in the graph. Note: if the node in the graph has a null value for a tag
   * then it will not be returned in the list
   *
   * @return
   */
  public List<String> getDistinctEntityTypes() {
    return getAllEntities()
            .stream()
            .map(n -> n.getType())
            .distinct()
            .collect(Collectors.toList());
  }

}
