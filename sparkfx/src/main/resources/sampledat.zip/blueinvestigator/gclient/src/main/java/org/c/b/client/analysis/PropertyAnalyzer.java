package org.c.b.client.analysis;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.createathon.blueinvestigate.graph.entities.Entity;
import org.createathon.blueinvestigate.graph.entities.Field;

/**
 *
 * @author aosama
 */
public class PropertyAnalyzer {

  private List<Entity> lstEntities;
  private List<propertyRecord> lstProperties;
  private List<Field> lstFields;

  public PropertyAnalyzer() {
    this.lstEntities = new ArrayList<>();
    this.lstFields = new ArrayList<>();
    lstProperties = new ArrayList<>();
  }

  public Integer getEntityCount() {
    return this.lstEntities.size();
  }

  public void initialize(List<Entity> lstEntities) {
    this.lstEntities = lstEntities;
    lstFields = new ArrayList<>();
    lstProperties = new ArrayList<>();
    //extracting all fields
    lstEntities.stream().forEach((entity)
            -> {
      lstFields.addAll(entity.getFieldsList());
    });

    lstFields.stream().forEach((Field f)
            -> {
      propertyRecord record = new propertyRecord();
      record.setEntityType(f.getBlueParentEntityType());
      record.setPropertyDataType(f.getDataType());
      record.setPropertyName(f.getBlueFieldName());
      if (f.getValue() != null) {
        record.setPropertyValue(f.getValue().toString());
      }

      lstProperties.add(record);
    });
  }

  public List<Field> getFieldsHavingProperty(String propertyName) {
    List<Field> lstFilteredFields = lstFields.stream()
            .filter(e -> e.getBlueFieldName().equals(propertyName))
            .collect(Collectors.toList());
    return lstFilteredFields;
  }

//    public Integer getPropertyRepeatCount(String propertyName)
//    {
//        return getFieldsHavingProperty(propertyName).size();
//    }
  public List<String> getUniquePropertyNames() {
    return lstFields.stream()
            .map(e -> e.getBlueFieldName())
            .distinct()
            .collect(Collectors.toList());
  }

  public Integer getRepeatCountForPropertyValue(String propertyName, String propertyValue) {
    List<String> propertyValues = getPropertyValues(propertyName);

    long count = propertyValues.stream()
            .filter(e -> e != null)
            .filter(e -> e.equals(propertyValue))
            .count();
    return (int) (long) count;
  }

  public List<String> getPropertyValues(String propertyName) {
    return lstProperties.stream()
            .filter(e -> e.getPropertyName().equals(propertyName))
            .map(e -> e.getPropertyValue())
            .collect(Collectors.toList());
  }

  public List<String> getUniqueValuesForProperty(String propertyName) {
    List<Field> fieldsHavingProperty = getFieldsHavingProperty(propertyName);

    return fieldsHavingProperty.stream()
            .filter(e -> e.getValue() != null)
            .map(e -> e.getValue().toString())
            .distinct()
            .collect(Collectors.toList());
  }

  public Integer getEntityCountHavingPropertyName(String propName) {
    long count = lstEntities.stream()
            .filter(e -> e.getFieldNames().contains(propName))
            .count();
    Integer c = (int) count;
    return c;
  }

  class propertyRecord {

    private String entityType;
    private String propertyName;
    private String propertyDataType;
    private String propertyValue;

    public String getEntityType() {
      return entityType;
    }

    public void setEntityType(String entityType) {
      this.entityType = entityType;
    }

    public String getPropertyName() {
      return propertyName;
    }

    public void setPropertyName(String propertyName) {
      this.propertyName = propertyName;
    }

    public String getPropertyDataType() {
      return propertyDataType;
    }

    public void setPropertyDataType(String propertyDataType) {
      this.propertyDataType = propertyDataType;
    }

    public String getPropertyValue() {
      return propertyValue;
    }

    public void setPropertyValue(String propertyValue) {
      this.propertyValue = propertyValue;
    }

  }

}
