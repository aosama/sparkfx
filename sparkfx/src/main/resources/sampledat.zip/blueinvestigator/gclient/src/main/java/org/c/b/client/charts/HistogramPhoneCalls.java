package org.c.b.client.charts;

import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

/**
 *
 * @author Ahmed Osama
 */
public class HistogramPhoneCalls
{

    final static String austria = "Austria";
    final static String brazil = "Brazil";
    final static String france = "France";
    final static String italy = "Italy";
    final static String usa = "USA";

    public static BarChart<String, Number> getPhoneCallsHistogram()
    {
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> barchart = new BarChart<>(xAxis, yAxis);
        //barchart.setTitle("Country Summary");
        //xAxis.setLabel("Country");
        //yAxis.setLabel("Value");

        XYChart.Series series1 = new XYChart.Series();
        //series1.setName("2003");
        series1.getData().add(new XYChart.Data(austria, 25601.34));
        series1.getData().add(new XYChart.Data(brazil, 20148.82));
        series1.getData().add(new XYChart.Data(france, 10000));
        series1.getData().add(new XYChart.Data(italy, 35407.15));
        series1.getData().add(new XYChart.Data(usa, 12000));

        //Scene scene = new Scene(bc, 800, 600);
        barchart.getData().addAll(series1);

        //height
        barchart.setPrefHeight(300);
        barchart.setAnimated(true);
        barchart.setLegendVisible(false);
        return barchart;
    }
}
