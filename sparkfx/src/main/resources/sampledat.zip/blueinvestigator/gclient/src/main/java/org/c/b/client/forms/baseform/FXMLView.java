package org.c.b.client.forms.baseform;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 *
 * @author aosama
 */
public abstract class FXMLView {

  protected Alert createBlankDialog(String title) {
    Alert alert = new Alert(AlertType.INFORMATION);

    alert.setTitle(title);
    //alert.setHeaderText("Look, an Information Dialog");
    //alert.setContentText("I have a great message for you!");
    //Dialog dlg = new Dialog(null, title, false, DialogStyle.CROSS_PLATFORM_DARK);
    return alert;
  }

  public void showMessageInformation(String title, String message) {
    Alert alert = new Alert(AlertType.INFORMATION);
    alert.setTitle(title);
    alert.setHeaderText(title);
    alert.setContentText(message);
    alert.showAndWait();
//    Dialogs.create()
//            .title(title)
//            .masthead(title)
//            .message(message)
//            .showInformation();

  }

  public void showExceptionDialog(String title, String header, String message, Throwable ex) {
    Alert alert = new Alert(AlertType.ERROR);
    alert.setTitle(title);
    alert.setHeaderText(title);
    alert.setContentText(message);
    alert.showAndWait();

  }
}
