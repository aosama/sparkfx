package org.c.b.client.forms.expandentity;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.c.b.client.forms.baseform.FXMLView;
import org.c.b.client.forms.wiring.Wiring;
import org.c.b.client.interfaces.IFXDialog;
import org.controlsfx.control.CheckListView;
import org.createathon.blueinvestigate.graph.entities.Entity;
import org.createathon.blueinvestigate.graph.entities.EntityReader;

/**
 *
 * @author aosama
 */
public class FrmExpandEntityController extends FXMLView implements Initializable, IFXDialog {

  //root node for dialog
  private Parent rootNode;

  private final EntityReader entityReader = new EntityReader();
  public VBox vBoxLstLinks;
  private final CheckListView<String> linkTypesCheckList;
  private List<Entity> selectedEntities;
  private final ObservableList<String> linkTypesStringList;

  public FrmExpandEntityController() {
    linkTypesStringList = FXCollections.observableArrayList();
    linkTypesCheckList = new CheckListView<>(linkTypesStringList);
  }

  @Override
  public void initialize(URL location, ResourceBundle resources) {
    System.out.println("FrmExpandEntityController initialized");
    linkTypesCheckList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    vBoxLstLinks.getChildren().add(linkTypesCheckList);
  }

  @Override
  public void showDialog(Parent rootNode) {
    Alert dlg = createBlankDialog("Expand Entity");
    dlg.getDialogPane().setContent(rootNode);
    //dlg.setContent(rootNode);
    this.rootNode = rootNode;
    //dlg.setClosable(false);
    //dlg.setResizable(false);
    dlg.show();
  }

  @Override
  public void initializeDialogData(Object dialogData) {
    this.selectedEntities = (List<Entity>) dialogData;
    List<String> linkTypes = entityReader.findLinkTypes(selectedEntities.stream().map(e -> e.getType()).collect(Collectors.toList()));

    linkTypesStringList.addAll(linkTypes);
    Wiring.getActiveGraph().showProgressBar();
    Wiring.getActiveGraph().progressBar.progressProperty().unbind();
    Wiring.getActiveGraph().progressBar.setProgress(0);
  }

  public void doExpand() {
    System.out.println("do expand called");
    System.out.println(linkTypesCheckList.getCheckModel().getCheckedIndices());

    Task linkExpanderTask = createLinkExpanderTask();

    Wiring.getActiveGraph().progressBar.progressProperty().bind(linkExpanderTask.progressProperty());

    linkExpanderTask.run();
    //new Thread(linkExpanderTask).start();

  }

  public Task createLinkExpanderTask() {
    return new Task() {

      @Override
      protected void succeeded() {
        Stage stage = (Stage) rootNode.getScene().getWindow();
        stage.close();
        Wiring.updateSubscribers();
        Wiring.getActiveGraph().hideProgressBar();
        Wiring.getActiveGraph().blueLayouter.doOrganicLayout();
      }

      @Override
      protected Object call() throws Exception {
        int i = 0;
        for (Entity e : selectedEntities) {
          i = i + 1;
          updateProgress(i, selectedEntities.size());

          linkTypesCheckList.getCheckModel().getCheckedIndices().stream().forEach(index
                  -> {
            if (entityReader.doesEntitySupportThisLink(e.getType(), linkTypesCheckList.getCheckModel().getItem(index))) {
              System.out.println("will call expand entity for " + e.getType() + " linktype is " + linkTypesCheckList.getCheckModel().getItem(index));
              Wiring.getActiveGraph().graphAnalysis.expandLinkForEntity(e, linkTypesCheckList.getCheckModel().getItem(index));
            }
          });
        }

        return true;
      }
    };
  }

}
