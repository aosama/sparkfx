package org.c.b.client.forms.graph;

import com.sun.glass.ui.Robot;
import com.yworks.yfiles.geometry.SizeD;
import com.yworks.yfiles.graph.IModelItem;
import com.yworks.yfiles.graph.INode;
import com.yworks.yfiles.graphml.GraphMLIOHandler;
import com.yworks.yfiles.view.GraphControl;
import com.yworks.yfiles.view.ISelectionModel;
import com.yworks.yfiles.view.Mouse2DEvent;
import com.yworks.yfiles.view.MouseButtons;
import com.yworks.yfiles.view.input.GraphEditorInputMode;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.control.ProgressBar;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import org.c.b.client.analysis.GraphAnalysis;
import org.c.b.client.charts.HistogramPhoneCalls;
import org.c.b.client.forms.baseform.FXMLView;
import org.c.b.client.forms.wiring.Wiring;
import org.c.b.client.layout.BlueLayouter;
import org.c.b.client.layout.OrganicLayoutParameters;
import org.c.b.client.radialmenu.RadialMenuSample;
import org.createathon.blueinvestigate.graph.entities.Entity;

/**
 *
 * @author Ahmed Osama
 */
public class FrmGraphController extends FXMLView implements Initializable {

  @FXML
  private VBox graphvbox;

  @FXML
  private AnchorPane graphAnchorPane;

  Robot robot = com.sun.glass.ui.Application.GetApplication().createRobot();
  public ProgressBar progressBar;
  RadialMenuSample radialMenuSample = new RadialMenuSample();
  public GraphControl graphControl;
  public BlueLayouter blueLayouter;

  private GraphEditorInputMode inputMode;
  public GraphAnalysis graphAnalysis;

  private final OrganicLayoutParameters organicLayoutParameters = new OrganicLayoutParameters();

  @Override
  public void initialize(URL url, ResourceBundle rb) {
    System.out.println("Initializing Graph");
    // Creates and configures a node style.

    inputMode = new GraphEditorInputMode();

    graphControl.setOnKeyPressed(new EventHandler<KeyEvent>() {

      @Override
      public void handle(KeyEvent event) {
        if (event.getCode() == KeyCode.DELETE) {
          inputMode.deleteSelection();
          Wiring.updateSubscribers();
        }
      }
    });

    //graphControl.getGraph().getNodeDefaults().setStyle(new ShinyPlateNodeStyle(Color.BLUE));
    //graphControl.getGraph().getEdgeDefaults().getLabels().setLabelModelParameter(NinePositionsEdgeLabelModel.SOURCE_ABOVE);
    graphControl.setInputMode(inputMode);

    Wiring.setActiveGraph(this);
    graphAnalysis = new GraphAnalysis(graphControl.getGraph(), this);
    blueLayouter = new BlueLayouter(graphControl, organicLayoutParameters);
    initializeGraphDefaults();

    //creating a new progress bar and adding it to the form
    progressBar = new ProgressBar(0);
    hideProgressBar();

    //events
    //graphControl.addEventFilter(com.yworks.yfiles.sup, null);
//    graphControl.getSelection().addItemSelectedListener((Object arg0, ItemEventArgs<IModelItem> arg1)
//            -> {
//      handleSelectionChange();
//    });
//
//    graphControl.getSelection().addItemDeselectedListener((Object arg0, ItemEventArgs<IModelItem> arg1)
//            -> {
//      handleSelectionChange();
//    });
    //add the radial menu and hide it
    graphControl.setOnMouse2DClicked(new EventHandler<Mouse2DEvent>() {
      @Override
      public void handle(Mouse2DEvent event) {
        if (event.getChangedButtons().equals(MouseButtons.RIGHT)) {
          Node oldMenu = null;
          for (Node n : graphAnchorPane.getChildren()) {
            if (n.getId().equals("rmenu")) {
              oldMenu = n;
            }
          }

          if (oldMenu != null) {
            graphAnchorPane.getChildren().remove(oldMenu);
          }

          radialMenuSample = new RadialMenuSample();
          Node radialMenu = radialMenuSample.getRadialMenu();
          radialMenu.setId("rmenu");
          graphAnchorPane.getChildren().add(radialMenu);
          radialMenuSample.showRadialMenu(robot.getMouseX(), robot.getMouseY() - 100);

          System.out.println("mouse clicked X:" + robot.getMouseX() + " Y:" + (robot.getMouseY() - 100));
        }
      }
    });

  }

  public void expandSelectedEntities() {
    graphAnalysis.expandLinksforEntities(getSelectedEntities());
    blueLayouter.doOrganicLayout();
  }

  private void handleSelectionChange() {

  }

  public void showProgressBar() {
//    System.out.println("show progress called");
//    graphvbox.getChildren().add(progressBar);
//    progressBar.prefWidthProperty().bind(graphvbox.widthProperty());
  }

  public void hideProgressBar() {
//    progressBar.progressProperty().unbind();
//    graphvbox.getChildren().remove(progressBar);
  }

  private void initializeGraphDefaults() {
    //SimpleLabelStyle labelStyle = new SimpleLabelStyle();
    //labelStyle.setBackgroundPaint(Color.WHITE);
    //labelStyle.setTextFormat(new TextFormat(new Font(20)));

//    graphControl.getGraph().getNodeDefaults().set
//    graphControl.getGraph().getNodeDefaults().getLabels().setStyle(labelStyle);
//    graphControl.getGraph().getNodeDefaults().getLabels().setLabelModelParameter(ExteriorLabelModel.SOUTH);
//    graphControl.getGraph().getEdgeDefaults().getLabels().setStyle(labelStyle);
//
//    graphControl.getGraph().getNodeDefaults().setStyle(new BevelNodeStyle());
    graphControl.getGraph().getNodeDefaults().setSize(new SizeD(50, 50));
  }

  public void encodeAsGraphML() {
    // Instantiate a GraphML I/O handler and write the graph to file.
    try {
      GraphMLIOHandler ioh = new GraphMLIOHandler();
      ioh.write(graphControl.getGraph(), "MyGraphML.graphml");
    } catch (IOException ioEx) {
      Logger.getLogger(FrmGraphController.class.getName()).log(Level.INFO, "error during graphml export", ioEx);
    }
  }

  public void loadCellPhone(String cellPhoneNumber) {
    try {
      graphAnalysis.loadCellPhone(cellPhoneNumber);
      blueLayouter.doCircularLayouter();
      graphControl.fitContent();
    } catch (Exception ex) {
      showMessageInformation("Cell phone number not found", "Cell phone number not found");
      Logger.getLogger(FrmGraphController.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  public void showHistogramPhoneCalls() {
    BarChart<String, Number> phoneCallsHistogram = HistogramPhoneCalls.getPhoneCallsHistogram();
    this.graphvbox.getChildren().add(phoneCallsHistogram);
  }

  public void clearSelectedEntities() {
    graphControl.getSelection().clear();
  }

  public void selectAllEntities() {
    graphControl.getGraph().getNodes()
            .stream()
            .forEach(n -> graphControl.getSelection().setSelected(n, true));
  }

  public void selectEntities(String entityTypeString) {
    graphControl.getGraph().getNodes()
            .stream()
            .filter(n -> n.getTag() != null)
            .filter(n -> ((Entity) n.getTag()).getType().equals(entityTypeString))
            .forEach(n -> graphControl.getSelection().setSelected(n, true));
  }

  public List<Entity> getSelectedEntities() {

    ISelectionModel<INode> selectedNodes = graphControl.getSelection().getSelectedNodes();
    List<Entity> entitiesList = new ArrayList<>();

    selectedNodes.forEach((IModelItem t)
            -> {
      if (t.getTag() instanceof Entity) {
        entitiesList.add((Entity) t.getTag());
      }
    });

    return entitiesList;
  }

  public void deleteSelection() {
    inputMode.deleteSelection();
    Wiring.updateSubscribers();
  }

}
