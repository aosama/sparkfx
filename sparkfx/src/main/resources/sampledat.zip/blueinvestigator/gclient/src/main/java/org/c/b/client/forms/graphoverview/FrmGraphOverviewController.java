package org.c.b.client.forms.graphoverview;

import org.c.b.client.forms.baseform.FXMLView;
import org.c.b.client.forms.wiring.Wiring;
import com.yworks.yfiles.view.GraphOverviewControl;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;

/**
 *
 * @author aosama
 */
public class FrmGraphOverviewController extends FXMLView implements Initializable {

  public GraphOverviewControl overviewControl;

  @Override
  public void initialize(URL location, ResourceBundle resources) {
    // setup the overview.
    overviewControl.setGraphControl(Wiring.getActiveGraph().graphControl);

    overviewControl.setHorizontalScrollBarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
    overviewControl.setVerticalScrollBarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
  }

}
