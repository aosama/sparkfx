package org.c.b.client.forms.main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.c.b.client.FormLoader;
import org.c.b.client.forms.graph.FrmGraphController;
import org.c.b.client.forms.graphoverview.FrmGraphOverviewController;
import org.c.b.client.forms.wiring.Wiring;
import org.c.b.client.stylesheets.MyStyleSheet;

public class FrmMainController implements Initializable {

  @FXML
  private TabPane mainTabPane;

  @FXML
  VBox rightvbox;

  @FXML
  private VBox leftVbox;

  private static final Stage stage = new Stage();

  @Override
  public void initialize(URL url, ResourceBundle rb) {
    System.out.println("Initializing Main form");

    createEmptyGraph();

    //add graph overview to main form
    //FrmGraphOverviewController frmGraphOverviewController = new FrmGraphOverviewController();
    //Parent view = frmGraphOverviewController.getView();
    rightvbox.getChildren().add(FormLoader.createView(FrmGraphOverviewController.class));

    Wiring.setFrmMainController(this);
  }

  public static void showMainForm() {
    FXMLLoader loader = new FXMLLoader(FrmMainController.class.getResource("FrmMain.fxml"));
    Parent parent = null;
    try {
      parent = (Parent) loader.load();
    } catch (IOException ex) {
      Logger.getLogger(FrmMainController.class.getName()).log(Level.SEVERE, null, ex);
    }
    Scene scene = new Scene(parent);
    scene.getStylesheets().add(MyStyleSheet.class.getResource("Styles.css").toExternalForm());
    stage.setTitle("Blue Investigate");
    stage.setScene(scene);
    stage.setMaximized(true);

    stage.show();
  }

  public void createEmptyGraph() {
    Tab myTab = new Tab();
    myTab.setText("Graph 1");

    //FrmGraphController frmGraphController = new FrmGraphController();
    //myTab.setContent(frmGraphController.getView());
    myTab.setContent(FormLoader.createView(FrmGraphController.class));
    mainTabPane.getTabs().add(myTab);
  }

  public void exportGraphML() {
    Wiring.getActiveGraph().encodeAsGraphML();
  }

}
