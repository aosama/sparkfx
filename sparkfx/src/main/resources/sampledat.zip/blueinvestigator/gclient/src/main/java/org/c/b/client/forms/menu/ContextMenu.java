package org.c.b.client.forms.menu;

/**
 *
 * @author aosama
 */
public class ContextMenu
{

    public void createMenu()
    {
        //RadialMenu radialMenu = new RadialMenu();

    }
}
