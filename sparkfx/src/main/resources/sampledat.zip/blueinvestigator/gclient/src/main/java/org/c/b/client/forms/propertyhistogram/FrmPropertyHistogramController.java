package org.c.b.client.forms.propertyhistogram;

import org.c.b.client.analysis.PropertyAnalyzer;
import org.c.b.client.forms.baseform.FXMLView;
import org.c.b.client.forms.sidebar.propretyexplorer.PropertyStatisticRecord;
import org.c.b.client.forms.wiring.Wiring;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.util.Callback;

/**
 *
 * @author Ahmed Ibrahim
 */
public class FrmPropertyHistogramController extends FXMLView implements Initializable
{

    //private PropertyStatisticsHolder propertyStatisticsHolder;
    @FXML
    TreeTableView<PropertyStatisticRecord> treeTable;

    @FXML
    TreeTableColumn<PropertyStatisticRecord, String> attributeColumn;

    @FXML
    TreeTableColumn<PropertyStatisticRecord, PropertyStatisticRecord> progressColumn;

    @FXML
    TreeTableColumn<PropertyStatisticRecord, Integer> valueCountColumn;

    private TreeItem<PropertyStatisticRecord> root;
    PropertyAnalyzer propertyAnalyzer = new PropertyAnalyzer();

    @Override
    public void initialize(URL location, ResourceBundle resources)
    {
        root = new TreeItem<>();
        root.setValue(new PropertyStatisticRecord("root", "dummyvalue", 0, 0));

        //Bind Attribute Column to its value
        //this column holds either a propertyName OR a Property Value
        attributeColumn.setCellValueFactory((TreeTableColumn.CellDataFeatures<PropertyStatisticRecord, String> param) ->
        {
            if (param.getValue().getValue() == null)
            {
                System.out.println("value was null");
            }
            PropertyStatisticRecord propStatRecord = param.getValue().getValue();
            if (propStatRecord.getPropertyName().equals(""))
            {
                return new SimpleObjectProperty<>(propStatRecord.getPropertyValue());
            } else
            {
                return new SimpleObjectProperty<>(propStatRecord.getPropertyName());
            }
        });

        //Bind the count column -- this colums will either show the total number
        //of occurences for a property name OR it will show an occurance count
        //for a unique value for a certain property
        valueCountColumn.setCellValueFactory((TreeTableColumn.CellDataFeatures<PropertyStatisticRecord, Integer> param) ->
        {
            PropertyStatisticRecord propStatRecord = param.getValue().getValue();
            return new SimpleObjectProperty<>(propStatRecord.getPropertyValueRepeatCount());
        });

        //Bind the progress bar column, which actually doesnt show a progress
        //but it shows a percentage for example if we have 20 occurences of a
        //property we then devide the 20 by the total number of entities in the
        //graph and then display it as a bar showing the significance of this
        //property to the total number of entities
        progressColumn.setCellValueFactory(new Callback<TreeTableColumn.CellDataFeatures<PropertyStatisticRecord, PropertyStatisticRecord>, ObservableValue<PropertyStatisticRecord>>()
        {

            @Override
            public ObservableValue<PropertyStatisticRecord> call(TreeTableColumn.CellDataFeatures<PropertyStatisticRecord, PropertyStatisticRecord> param)
            {
                PropertyStatisticRecord propertyStatisticRecord = param.getValue().getValue();
                return new SimpleObjectProperty<>(propertyStatisticRecord);
            }
        });
        progressColumn.setCellFactory(new Callback<TreeTableColumn<PropertyStatisticRecord, PropertyStatisticRecord>, TreeTableCell<PropertyStatisticRecord, PropertyStatisticRecord>>()
        {

            @Override
            public TreeTableCell<PropertyStatisticRecord, PropertyStatisticRecord> call(TreeTableColumn<PropertyStatisticRecord, PropertyStatisticRecord> param)
            {
                return new MyBarCell();
            }
        });

        root.setExpanded(true);

        treeTable.getSortOrder().add(valueCountColumn);
        treeTable.setShowRoot(false);
        treeTable.setRoot(root);
        Wiring.setFrmPropertyHistogramController(this);
    }

    public void updateHistogram()
    {
        System.out.println("update histogram called");
        //updateHolder();
        propertyAnalyzer.initialize(Wiring.getActiveGraph().graphAnalysis.getAllEntities());
        root.getChildren().clear();

        propertyAnalyzer.getUniquePropertyNames().forEach((String propName) ->
        {
            TreeItem<PropertyStatisticRecord> item = new TreeItem<>();
            PropertyStatisticRecord record = new PropertyStatisticRecord();

            record.setPropertyName(propName);
            record.setEntityCountHavingThisPropertyName(propertyAnalyzer.getEntityCountHavingPropertyName(propName));
            record.setPropertyValueRepeatCount(propertyAnalyzer.getEntityCountHavingPropertyName(propName));
            //record.setPropertyValueRepeatCount(propertyAnalyzer.getRepeatCountForPropertyValue(propName));
            record.setRootRecord(true);
            record.setTotalEntityCount(propertyAnalyzer.getEntityCount());

            item.setValue(record);
            item.setExpanded(true);
            root.getChildren().add(item);

            //get values , their count and add them to the property tree node
            propertyAnalyzer.getUniqueValuesForProperty(propName).forEach((String propValue) ->
            {
                TreeItem<PropertyStatisticRecord> childNode = new TreeItem<>();
                PropertyStatisticRecord childRecord = new PropertyStatisticRecord();
                childRecord.setPropertyName("");
                childRecord.setPropertyValue(propValue);
                childRecord.setPropertyValueRepeatCount(propertyAnalyzer.getRepeatCountForPropertyValue(propName, propValue));
                childRecord.setRootRecord(false);
                childRecord.setTotalEntityCount(propertyAnalyzer.getEntityCount());
                childRecord.setEntityCountHavingThisPropertyName(propertyAnalyzer.getEntityCountHavingPropertyName(propName));
                childNode.setValue(childRecord);
                item.getChildren().add(childNode);
            });
        });
    }
}
