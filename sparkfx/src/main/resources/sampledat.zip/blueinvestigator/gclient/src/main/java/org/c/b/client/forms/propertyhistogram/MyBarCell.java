package org.c.b.client.forms.propertyhistogram;

import org.c.b.client.forms.sidebar.propretyexplorer.PropertyStatisticRecord;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TreeTableCell;

/**
 *
 * @author Ahmed Ibrahim
 */
public class MyBarCell extends TreeTableCell<PropertyStatisticRecord, PropertyStatisticRecord>
{

    @Override
    protected void updateItem(PropertyStatisticRecord item, boolean empty)
    {
        super.updateItem(item, empty); //To change body of generated methods, choose Tools | Templates.
        if (item != null || !empty)
        {
            double pbValue;
            if (item.isRootRecord())
            {
                //pbValue = (double) item.getEntityCountHavingThisPropertyName() / item.getTotalEntityCount();
                setGraphic(null);
            } else
            {
                pbValue = (double) item.getPropertyValueRepeatCount() / item.getEntityCountHavingThisPropertyName();
                ProgressBar pb = new ProgressBar(pbValue);
                pb.setMaxWidth(1000);
                setGraphic(pb);
            }

        }
    }

}
