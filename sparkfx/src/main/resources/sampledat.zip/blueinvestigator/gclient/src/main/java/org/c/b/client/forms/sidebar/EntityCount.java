package org.c.b.client.forms.sidebar;

/**
 *
 * @author aosama
 */
public class EntityCount
{

    private String entityType;
    private Long entityCount;

    public EntityCount(String entityType, Long entityCount)
    {
        this.entityType = entityType;
        this.entityCount = entityCount;
    }

    public Long getEntityCount()
    {
        return entityCount;
    }

    public String getEntityType()
    {
        return entityType;
    }

    public void setEntityCount(Long entityCount)
    {
        this.entityCount = entityCount;
    }

    public void setEntityType(String entityType)
    {
        this.entityType = entityType;
    }

}
