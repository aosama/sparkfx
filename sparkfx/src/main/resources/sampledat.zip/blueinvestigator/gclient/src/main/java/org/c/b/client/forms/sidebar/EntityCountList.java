package org.c.b.client.forms.sidebar;

import java.util.Iterator;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author aosama
 */
public class EntityCountList
{

    private final ObservableList<EntityCount> lstEntityCount;
    private Long totalEntityCount;

    public EntityCountList()
    {
        lstEntityCount = FXCollections.observableArrayList();
    }

    public ObservableList<EntityCount> getList()
    {
        return this.lstEntityCount;
    }

    public EntityCount get(int index)
    {
        return lstEntityCount.get(index);
    }

    public void upsert(EntityCount entityCount)
    {
        upsert(entityCount, true);
    }

    private void upsert(EntityCount entityCount, boolean updateTotalCount)
    {
        int i = 0;
        for (EntityCount e : lstEntityCount)
        {
            if (e.getEntityType().equals(entityCount.getEntityType()))
            {
                lstEntityCount.set(i, entityCount);
                if (updateTotalCount)
                {
                    updateTotalEntityCount();
                    sortList();
                }
                return;
            }
            i++;
        }
        lstEntityCount.add(entityCount);
        sortList();
    }

    private void updateTotalEntityCount()
    {
        this.totalEntityCount = lstEntityCount.stream()
                .filter(e -> !e.getEntityType().equals("All Entities"))
                .mapToLong(e -> e.getEntityCount())
                .summaryStatistics()
                .getSum();

        EntityCount e = new EntityCount("All Entities", totalEntityCount);
        upsert(e, false);
    }

    public void reconcile(List<String> entityTypesList)
    {
        Iterator<EntityCount> iterator = lstEntityCount.iterator();
        while (iterator.hasNext())
        {
            if (entityTypesList.contains(iterator.next().getEntityType()) == false)
            {
                iterator.remove();
            }
        }
        sortList();
        updateTotalEntityCount();
    }

    private void sortList()
    {
        FXCollections.sort(lstEntityCount, (EntityCount o1, EntityCount o2) -> o2.getEntityCount().compareTo(o1.getEntityCount()));
    }

    public Long getTotalEntityCount()
    {
        return totalEntityCount;
    }

}
