package org.c.b.client.forms.sidebar;

import java.net.URL;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import org.c.b.client.FormLoader;
import org.c.b.client.forms.baseform.FXMLView;
import org.c.b.client.forms.expandentity.FrmExpandEntityController;
import org.c.b.client.forms.wiring.Wiring;
import org.c.b.client.radialmenu.RadialMenuSample;
import org.createathon.blueinvestigate.graph.entities.Entity;
import org.createathon.blueinvestigate.graph.entities.EntityReader;
import org.createathon.blueinvestigate.graph.entities.Field;

/**
 *
 * @author aosama
 */
public class FrmSideBarController extends FXMLView implements Initializable {

  //should be removed after enabling search
  @FXML
  TextField txtCellPhone;

  @FXML
  private VBox vBoxFilters;

  @FXML
  private VBox vBoxData;

  @FXML
  private VBox vboxPropertyExplorer;

  @FXML
  VBox vboxHistogram;

  @FXML
  private AnchorPane anchorPaneForEntityStats;

  @FXML
  private TableView<EntityCount> tblEntityStatistics;
  @FXML
  TableColumn<EntityCount, String> entityTypeCol;
  @FXML
  TableColumn<EntityCount, Long> entityCountCol;

  private final EntityCountList entityCountList = new EntityCountList();

  @Override
  public void initialize(URL location, ResourceBundle resources) {
    tblEntityStatistics.setVisible(false);

    entityTypeCol.setCellValueFactory(new PropertyValueFactory<>("entityType"));
    //entityCountCol.setCellValueFactory(new PropertyValueFactory<>("entityCount"));
    entityCountCol.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<EntityCount, Long>, ObservableValue<Long>>() {

      @Override
      public ObservableValue<Long> call(TableColumn.CellDataFeatures<EntityCount, Long> param) {
        //some comment
        return new SimpleObjectProperty<>(param.getValue().getEntityCount());
      }
    });

    entityCountCol.setSortType(TableColumn.SortType.DESCENDING);

    tblEntityStatistics.setItems(entityCountList.getList());

    tblEntityStatistics.setOnMouseClicked((MouseEvent event) -> onFilterTableClicked(event));
    tblEntityStatistics.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    tblEntityStatistics.getSortOrder().add(entityCountCol);
    Wiring.setSideBarController(this);

    RadialMenuSample radialMenuSample = new RadialMenuSample();
    vBoxFilters.getChildren().add(radialMenuSample.getPanel());
  }

  private void onFilterTableClicked(MouseEvent event) {
    ObservableList<EntityCount> selectedItems = tblEntityStatistics.getSelectionModel().getSelectedItems();
    Wiring.getActiveGraph().clearSelectedEntities();

    for (EntityCount e : selectedItems) {
      if (e.getEntityType().equals("All Entities")) {
        Wiring.getActiveGraph().selectAllEntities();
        return;
      }
    }

    selectedItems.stream()
            .map(e -> e.getEntityType())
            .distinct()
            .forEach(e -> Wiring.getActiveGraph().selectEntities(e));

  }

  public void updateEntityStatistics() {
    System.out.println("update list called");

    //will get distinct entity types
    List<String> entityTypesList = Wiring.getActiveGraph().graphAnalysis.getDistinctEntityTypes();
    if (entityTypesList.isEmpty()) {
      tblEntityStatistics.setVisible(false);
    } else {
      tblEntityStatistics.setVisible(true);
    }

    entityTypesList.stream().forEach((typeString)
            -> {
      Long countEntityType = Wiring.getActiveGraph().graphAnalysis.countEntityType(typeString);
      entityCountList.upsert(new EntityCount(typeString, countEntityType));
    });

    entityCountList.reconcile(entityTypesList);

    //this code to shrink or expand the table
    //so it is height is the same as the content inside it
    if (!tblEntityStatistics.getItems().isEmpty()) {
      Double newHeight = (entityCountList.getList().size() + 1) * 25d;
      tblEntityStatistics.setPrefHeight(newHeight);
      tblEntityStatistics.setMaxHeight(newHeight);
      tblEntityStatistics.setMinHeight(newHeight);
    }

  }

  public void loadCountry() {
    EntityReader entityReader = new EntityReader();
    HashMap<String, Field> pkMap = entityReader.getBlankPrimaryKeyMapForEntity("Country");

    Field entry = pkMap.get("Country Code");
    entry.setValue("GH");
    pkMap.put("Country Code", entry);

    try {
      Wiring.getActiveGraph().graphAnalysis.loadEntity(pkMap, "Country");
      updateEntityStatistics();
//            Wiring.getActiveGraph().blueLayouter.doOrganicLayout();
    } catch (NullPointerException ex) {
      Logger.getLogger(FrmSideBarController.class.getName()).log(Level.SEVERE, null, ex);
      showExceptionDialog("Null Primary Key Error", "Null Primary Key Error", "The entity finder threw an error due to an empty primary key", ex);
    } catch (SQLException ex) {
      Logger.getLogger(FrmSideBarController.class.getName()).log(Level.SEVERE, null, ex);
      showExceptionDialog("Exception Error", "Error Accessing Target DB", "The server returned the following exception", ex);
    }
  }

  public void loadSingleCellPhoneEntity() throws Exception {
    EntityReader entityReader = new EntityReader();
    HashMap<String, Field> pkMap = entityReader.getBlankPrimaryKeyMapForEntity("mobile");

    Field entry = pkMap.get("cellnumber");
    entry.setValue("01001491278");
    pkMap.put("cellnumber", entry);

    try {
      Wiring.getActiveGraph().graphAnalysis.loadEntity(pkMap, "mobile");
//      Wiring.getActiveGraph().blueLayouter.doOrganicLayout();
    } catch (NullPointerException ex) {
      Logger.getLogger(FrmSideBarController.class.getName()).log(Level.SEVERE, null, ex);
      showExceptionDialog("Null Primary Key Error", "Null Primary Key Error", "The entity finder threw an error due to an empty primary key", ex);
    } catch (SQLException ex) {
      Logger.getLogger(FrmSideBarController.class.getName()).log(Level.SEVERE, null, ex);
      showExceptionDialog("Exception Error", "Error Accessing Target DB", "The server returned the following exception", ex);
    }
  }

  public void searchForEntity() {

  }

  public void expandSelectedEntities() {
    List<Entity> selectedEntities = Wiring.getActiveGraph().getSelectedEntities();
    if (selectedEntities.isEmpty()) {
      showMessageInformation("No Selection", "There is no entity selected from the graph");
    } else {
      FormLoader.showDialog(FrmExpandEntityController.class, selectedEntities);
    }
  }

  public void btnLoadOutgoingCalls() {
    Wiring.getActiveGraph().loadCellPhone(txtCellPhone.getText());
  }

  public void showHistogramPhoneCalls() {
    Wiring.getActiveGraph().showHistogramPhoneCalls();
  }

  public void showMsg() {
    showMessageInformation("Sdfdsf", "SFgsfg");
  }

  public void expandAll() {
    System.out.println("expand all called");
    Wiring.getActiveGraph().expandSelectedEntities();
    Wiring.updateSubscribers();

//        Task task = new Task<Void>()
//        {
//
//            @Override
//            protected Void call() throws Exception
//            {
//                Wiring.getActiveGraph().blueLayouter.doOrganicLayout();
//                return null;
//            }
//        };
//
//        new Thread(task).start();
  }
}
