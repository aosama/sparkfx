package org.c.b.client.forms.sidebar.propretyexplorer;

/**
 *
 * @author Ahmed Ibrahim
 */
public class PropertyStatisticRecord
{

    private String propertyName;
    private String propertyValue;
    private Integer propertyValueRepeatCount;
    private Integer entityCountHavingThisPropertyName;
    private Integer totalEntityCount;
    private boolean rootRecord;

    public PropertyStatisticRecord()
    {
    }

    public PropertyStatisticRecord(String propertyName, String propertyValue, Integer propertyValueRepeatCount, Integer entityCountHavingThisPropertyName, Integer totalEntityCount, boolean rootRecord)
    {
        this.propertyName = propertyName;
        this.propertyValue = propertyValue;
        this.propertyValueRepeatCount = propertyValueRepeatCount;
        this.entityCountHavingThisPropertyName = entityCountHavingThisPropertyName;
        this.totalEntityCount = totalEntityCount;
        this.rootRecord = rootRecord;
    }

    public PropertyStatisticRecord(String propertyName, String propertyValue, Integer propertyValueRepeatCount, Integer entityCountHavingThisPropertyName)
    {
        this.propertyName = propertyName;
        this.propertyValue = propertyValue;
        this.propertyValueRepeatCount = propertyValueRepeatCount;
        this.entityCountHavingThisPropertyName = entityCountHavingThisPropertyName;
        rootRecord = false;
    }

    public PropertyStatisticRecord(String propertyName, String propertyValue, Integer propertyValueRepeatCount, Integer entityCountHavingThisPropertyName, boolean rootRecord)
    {
        this.propertyName = propertyName;
        this.propertyValue = propertyValue;
        this.propertyValueRepeatCount = propertyValueRepeatCount;
        this.entityCountHavingThisPropertyName = entityCountHavingThisPropertyName;
        this.rootRecord = rootRecord;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

    public String getPropertyValue()
    {
        return propertyValue;
    }

    public void setPropertyValue(String propertyValue)
    {
        this.propertyValue = propertyValue;
    }

    public Integer getPropertyValueRepeatCount()
    {
        return propertyValueRepeatCount;
    }

    public void setPropertyValueRepeatCount(Integer propertyValueRepeatCount)
    {
        this.propertyValueRepeatCount = propertyValueRepeatCount;
    }

    public Integer getEntityCountHavingThisPropertyName()
    {
        return entityCountHavingThisPropertyName;
    }

    public void setEntityCountHavingThisPropertyName(Integer entityCountHavingThisPropertyName)
    {
        this.entityCountHavingThisPropertyName = entityCountHavingThisPropertyName;
    }

    public boolean isRootRecord()
    {
        return rootRecord;
    }

    public void setRootRecord(boolean rootRecord)
    {
        this.rootRecord = rootRecord;
    }

    public Integer getTotalEntityCount()
    {
        return totalEntityCount;
    }

    public void setTotalEntityCount(Integer totalEntityCount)
    {
        this.totalEntityCount = totalEntityCount;
    }

}
