package org.c.b.client.forms.sidebar.propretyexplorer;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author Ahmed Ibrahim
 */
public class PropertyStatisticsHolder
{

    private final List<PropertyStatisticsList> lstProperties;

    public PropertyStatisticsHolder()
    {
        lstProperties = new ArrayList<>();
    }

    public List<PropertyStatisticsList> getLstProperties()
    {
        return lstProperties;
    }

    private PropertyStatisticsList createNewList(String propertyName)
    {
        PropertyStatisticsList lst = new PropertyStatisticsList();
        lst.setPropertyName(propertyName);
        this.lstProperties.add(lst);
        return lst;
    }

    public PropertyStatisticsList findOrCreateList(String propertyName)
    {
        List<PropertyStatisticsList> collect = lstProperties.stream()
                .filter(e -> e.getPropertyName().equals(propertyName))
                .collect(Collectors.toList());
        if (collect.isEmpty())
        {
            return createNewList(propertyName);
        } else
        {
            return collect.get(0);
        }
    }

}
