package org.c.b.client.forms.sidebar.propretyexplorer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Ahmed Ibrahim
 */
public class PropertyStatisticsList
{

    private final ObservableList<PropertyStatisticRecord> lstPropStats;
    private Integer totalCount;
    private String propertyName;

    public PropertyStatisticRecord getRootNode()
    {
        for (PropertyStatisticRecord r : lstPropStats)
        {
            if (r.isRootRecord())
            {
                return r;
            }
        }
        return null;
    }

    public PropertyStatisticsList()
    {
        this.lstPropStats = FXCollections.observableArrayList();
    }

    public void upsert(PropertyStatisticRecord record)
    {
        PropertyStatisticRecord currentRecord = findRecordByPropName(record.getPropertyValue());
        if (currentRecord != null)
        {
            lstPropStats.remove(currentRecord);
        }
        lstPropStats.add(record);
    }

    private PropertyStatisticRecord findRecordByPropName(String propName)
    {
        for (PropertyStatisticRecord r : lstPropStats)
        {
            if (r.getPropertyName().equals(propName))
            {
                return r;
            }
        }
        return null;
    }

    public Integer getTotalCount()
    {
        return totalCount;
    }

    public void setTotalCount(Integer totalCount)
    {
        this.totalCount = totalCount;
    }

    public ObservableList<PropertyStatisticRecord> getLstPropStats()
    {
        return lstPropStats;
    }

    public String getPropertyName()
    {
        return propertyName;
    }

    public void setPropertyName(String propertyName)
    {
        this.propertyName = propertyName;
    }

}
