package org.c.b.client.forms.toolbars;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ToolBar;
import javafx.util.Duration;
import org.c.b.client.forms.baseform.FXMLView;
import org.c.b.client.forms.wiring.Wiring;
import org.c.b.client.utilities.Utils;

/**
 *
 * @author aosama
 */
public class GraphToolbarController extends FXMLView implements Initializable {

  @FXML
  ToolBar graphToolbar;

  @FXML
  Label memoryLabel;

  @Override
  public void initialize(URL location, ResourceBundle resources) {
    System.out.println("initializing graph toolbar");
    updateMemoryUsage();

    Timeline fiveSecondsWonder = new Timeline(new KeyFrame(Duration.seconds(1), (ActionEvent event)
            -> {
      updateMemoryUsage();
    }));
    fiveSecondsWonder.setCycleCount(Timeline.INDEFINITE);
    fiveSecondsWonder.play();
  }

  private void updateMemoryUsage() {
    memoryLabel.setText(Utils.getUsedMemoryAsString() + " / " + Utils.getTotalMemoryAsString());
  }

  public void zoomIn() {
    Wiring.getActiveGraph().graphControl.setZoom(Wiring.getActiveGraph().graphControl.getZoom() * 1.25);
  }

  public void zoomOut() {
    Wiring.getActiveGraph().graphControl.setZoom(Wiring.getActiveGraph().graphControl.getZoom() * 0.8);
  }

  public void fitBounds() {
    Wiring.getActiveGraph().graphControl.fitGraphBounds();
  }

  public void doCircularLayout() {
    Wiring.getActiveGraph().blueLayouter.doCircularLayouter();
  }

  public void doOrganicLayout() {
    //Wiring.getActiveGraph().blueLayouter.doOrganicLayout();
  }

  public void doHierarchicLayout() {
    //Wiring.getActiveGraph().blueLayouter.doHierarchicLayout();
  }

  public void doOrthogonalLayout() {
    //Wiring.getActiveGraph().blueLayouter.doOrthogonalLayout();
  }

  public void doBaloonLayout() {
//    Wiring.getActiveGraph().blueLayouter.doBaloonLayout();
  }
}
