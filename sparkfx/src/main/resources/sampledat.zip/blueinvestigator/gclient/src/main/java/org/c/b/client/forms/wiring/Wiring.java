package org.c.b.client.forms.wiring;

import org.c.b.client.forms.graph.FrmGraphController;
import org.c.b.client.forms.main.FrmMainController;
import org.c.b.client.forms.propertyhistogram.FrmPropertyHistogramController;
import org.c.b.client.forms.sidebar.FrmSideBarController;

/**
 *
 * @author aosama
 */
public class Wiring
{

    private static FrmGraphController activeGraph;
    private static FrmSideBarController sideBarController;
    private static FrmMainController frmMainController;
    private static FrmPropertyHistogramController frmPropertyHistogramController;

    public static void updateSubscribers()
    {
        sideBarController.updateEntityStatistics();
        if (frmPropertyHistogramController != null)
        {
            frmPropertyHistogramController.updateHistogram();
        }
    }

    public static FrmSideBarController getSideBarController()
    {
        return sideBarController;
    }

    public static void setSideBarController(FrmSideBarController sideBarController)
    {
        Wiring.sideBarController = sideBarController;
    }

    public static FrmGraphController getActiveGraph()
    {
        return activeGraph;
    }

    public static void setActiveGraph(FrmGraphController activeGraph)
    {
        Wiring.activeGraph = activeGraph;
    }

    public static FrmMainController getFrmMainController()
    {
        return frmMainController;
    }

    public static void setFrmMainController(FrmMainController frmMainController)
    {
        Wiring.frmMainController = frmMainController;
    }

    public static FrmPropertyHistogramController getFrmPropertyHistogramController()
    {
        return frmPropertyHistogramController;
    }

    public static void setFrmPropertyHistogramController(FrmPropertyHistogramController frmPropertyHistogramController)
    {
        Wiring.frmPropertyHistogramController = frmPropertyHistogramController;
    }

}
