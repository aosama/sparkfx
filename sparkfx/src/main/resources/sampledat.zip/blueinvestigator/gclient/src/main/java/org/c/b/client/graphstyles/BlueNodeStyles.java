package org.c.b.client.graphstyles;

import org.c.b.client.utilities.Utils;
import com.yworks.yfiles.geometry.RectD;
import com.yworks.yfiles.graph.styles.INodeStyle;
import com.yworks.yfiles.graph.styles.ImageNodeStyle;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.image.Image;
import org.createathon.blueinvestigate.graph.entities.EntityHelper;

/**
 *
 * @author aosama
 */
public class BlueNodeStyles {

  private static final EntityHelper entityHelper = new EntityHelper();

  public static INodeStyle getCircularPrimaryCellPhoneNodeStyle() {
    ImageNodeStyle im = null;
    try {
      im = new ImageNodeStyle(BlueNodeStyles.class.getResource("cellphone.png").toURI().toURL());
    } catch (URISyntaxException ex) {
      Logger.getLogger(BlueNodeStyles.class.getName()).log(Level.SEVERE, null, ex);
    } catch (MalformedURLException ex) {
      Logger.getLogger(BlueNodeStyles.class.getName()).log(Level.SEVERE, null, ex);
    }
    return im;
  }

  public static INodeStyle getDefaultNodeStyle(String entityName) {
    byte[] iconForEntity = entityHelper.getIconForEntity(entityName);

    String userDir = System.getProperty("user.dir");
    String fname = userDir + "\\" + entityName + ".png";

    try {
      ImageNodeStyle im;
      File file;
      if (Utils.checkIfFileExists(fname) == false) {
        file = Utils.createFileFromBytes(fname, iconForEntity);
        im = new ImageNodeStyle(file.toURI().toURL());
        System.out.println("creating image file for " + entityName);
      } else {
        file = new File(fname);
        im = new ImageNodeStyle(file.toURI().toURL());
      }
      return im;
    } catch (IOException ex) {
      Logger.getLogger(BlueNodeStyles.class.getName()).log(Level.SEVERE, null, ex);
    }
    return null;

  }

  public static RectD getRectangleForDefaultNodeStyle(String entityName) {
    byte[] iconForEntity = entityHelper.getIconForEntity(entityName);

    InputStream is = new ByteArrayInputStream(iconForEntity);

    Image img = new Image(is);

    RectD r = new RectD(1, 1, img.getWidth(), img.getHeight());

    return r;
  }

  public static INodeStyle getNormalCellPhoneNodeStyle() {
    ImageNodeStyle im = null;
    try {
      im = new ImageNodeStyle(BlueNodeStyles.class.getResource("cellphone4.png").toURI().toURL());
    } catch (URISyntaxException ex) {
      Logger.getLogger(BlueNodeStyles.class.getName()).log(Level.SEVERE, null, ex);
    } catch (MalformedURLException ex) {
      Logger.getLogger(BlueNodeStyles.class.getName()).log(Level.SEVERE, null, ex);
    }
    return im;
  }
}
