package org.c.b.client.interfaces;

import javafx.scene.Parent;

/**
 *
 * @author aosama
 */
public interface IFXDialog
{

    public void initializeDialogData(Object dialogData);

    public void showDialog(Parent rootNode);

}
