package org.c.b.client.layout;

import com.yworks.yfiles.layout.LayoutExecutor;
import com.yworks.yfiles.layout.circular.CircularLayout;
import com.yworks.yfiles.view.GraphControl;

/**
 *
 * @author aosama
 */
public class BlueLayouter {
//

  private final GraphControl graphControl;
//    private final double ANIMATION_TIME = 1.0;
  private final OrganicLayoutParameters organicLayoutParameters;
//

  public BlueLayouter(GraphControl graphControl, OrganicLayoutParameters organicLayoutParameters) {
    this.graphControl = graphControl;
    this.organicLayoutParameters = organicLayoutParameters;
  }
//

  public void doCircularLayouter() {
    CircularLayout circularLayout = new CircularLayout();
    LayoutExecutor layoutExecutor = new LayoutExecutor(graphControl, circularLayout);
    layoutExecutor.start();
    //LayoutExtensions.morphLayout(graphControl, new CircularLayouter(), Duration.seconds(ANIMATION_TIME), null);
    graphControl.fitGraphBounds();
  }

  public void doOrganicLayout() {

//        SmartOrganicLayouter smartOrganicLayouter = new SmartOrganicLayouter();
//        //x.setAttraction(2);
//        //x.setLayoutOrientation(LayoutOrientation.TOP_TO_BOTTOM);
//
//        //layout only selected nodes
//        smartOrganicLayouter.setScope(Scope.MAINLY_SUBSET);
//        smartOrganicLayouter.setNodeOverlapsAllowed(true);
//        smartOrganicLayouter.setSmartComponentLayoutEnabled(true);
//
//
//        smartOrganicLayouter.setPreferredEdgeLength(organicLayoutParameters.getPreferedEdgeLength());
//        //smartOrganicLayouter.seta
//        smartOrganicLayouter.setMinimalNodeDistance(organicLayoutParameters.getMinimalNodeDistance());
//        smartOrganicLayouter.setCompactness(organicLayoutParameters.getCompactness());
//        smartOrganicLayouter.setQualityTimeRatio(1.0); //1.0 is max quality
//        //smartOrganicLayouter.setMaximumDuration(10);
//        smartOrganicLayouter.setNodeSizeAware(true);
//        smartOrganicLayouter.setParallelEdgeLayouterEnabled(true);
//        smartOrganicLayouter.setNodeEdgeOverlapAvoided(true);
//        smartOrganicLayouter.setNodeLabelConsiderationEnabled(true);
//
//        if (graphControl.getGraph().getNodes().size() > 100)
//        {
//            System.out.println("WILL DO NORMAL ORGANIC LAYOUT");
//            LayoutExtensions.applyLayout(graphControl.getGraph(), smartOrganicLayouter);
//        } else
//        {
//            System.out.println("WILL DO ANIMATED MORPH ORGANIC LAYOUT");
//            LayoutExtensions.morphLayout(graphControl, smartOrganicLayouter, Duration.seconds(ANIMATION_TIME), null);
//        }
    graphControl.fitGraphBounds();
  }
//
//    public void doHierarchicLayout()
//    {
//        LayoutExtensions.morphLayout(graphControl, new IncrementalHierarchicLayouter(), Duration.seconds(ANIMATION_TIME), null);
//        graphControl.fitGraphBounds();
//    }
//
//    public void doVerticalTreeLayout()
//    {
//        LayoutExtensions.morphLayout(graphControl, new TreeLayouter(), Duration.seconds(ANIMATION_TIME), null);
//        graphControl.fitGraphBounds();
//    }
//
//    public void doOrthogonalLayout()
//    {
//        LayoutExtensions.morphLayout(graphControl, new OrthogonalLayouter(), Duration.seconds(ANIMATION_TIME), null);
//        graphControl.fitGraphBounds();
//    }
//
//    public void doBaloonLayout()
//    {
//
//        LayoutExtensions.morphLayout(graphControl, new BalloonLayouter(), Duration.seconds(ANIMATION_TIME), null);
//        graphControl.fitGraphBounds();
//    }
}
