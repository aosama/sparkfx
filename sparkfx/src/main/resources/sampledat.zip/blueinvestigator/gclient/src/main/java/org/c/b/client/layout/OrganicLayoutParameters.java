package org.c.b.client.layout;

/**
 *
 * @author aosama
 */
public class OrganicLayoutParameters
{

    private double preferedEdgeLength;
    private boolean considerNodeLabels;
    private double minimalNodeDistance;
    private boolean avoidNodeEdgeOverlaps;
    public double compactness; //maximumis 1
    public boolean useNaturalClustering;

    public OrganicLayoutParameters()
    {
        preferedEdgeLength = 40;
        considerNodeLabels = true;
        minimalNodeDistance = 20.0;
        avoidNodeEdgeOverlaps = true;
        compactness = 0.2;
        useNaturalClustering = false;
    }

    public double getPreferedEdgeLength()
    {
        return preferedEdgeLength;
    }

    public void setPreferedEdgeLength(double preferedEdgeLength)
    {
        this.preferedEdgeLength = preferedEdgeLength;
    }

    public boolean isConsiderNodeLabels()
    {
        return considerNodeLabels;
    }

    public void setConsiderNodeLabels(boolean considerNodeLabels)
    {
        this.considerNodeLabels = considerNodeLabels;
    }

    public double getMinimalNodeDistance()
    {
        return minimalNodeDistance;
    }

    public void setMinimalNodeDistance(double minimalNodeDistance)
    {
        this.minimalNodeDistance = minimalNodeDistance;
    }

    public boolean isAvoidNodeEdgeOverlaps()
    {
        return avoidNodeEdgeOverlaps;
    }

    public void setAvoidNodeEdgeOverlaps(boolean avoidNodeEdgeOverlaps)
    {
        this.avoidNodeEdgeOverlaps = avoidNodeEdgeOverlaps;
    }

    public double getCompactness()
    {
        return compactness;
    }

    public void setCompactness(double compactness)
    {
        this.compactness = compactness;
    }

    public boolean isUseNaturalClustering()
    {
        return useNaturalClustering;
    }

    public void setUseNaturalClustering(boolean useNaturalClustering)
    {
        this.useNaturalClustering = useNaturalClustering;
    }

}
