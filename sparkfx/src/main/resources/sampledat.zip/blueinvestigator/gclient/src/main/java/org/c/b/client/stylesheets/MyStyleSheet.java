package org.c.b.client.stylesheets;

/**
 *
 * @author aosama
 */
public class MyStyleSheet
{

}
