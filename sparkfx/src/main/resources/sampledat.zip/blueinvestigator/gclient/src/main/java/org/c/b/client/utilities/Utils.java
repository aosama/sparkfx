package org.c.b.client.utilities;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author aosama
 */
public class Utils
{

    public static String getTotalMemoryAsString()
    {
        Double m = (Runtime.getRuntime().totalMemory() / (1024d));
        m = m / 1024d;
        DecimalFormat formatter = new DecimalFormat("#,###.0");
        return formatter.format(m);
    }

    public static String getUsedMemoryAsString()
    {
        Double m = ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024d));
        m = m / 1024d;
        DecimalFormat formatter = new DecimalFormat("#,###.0");
        return formatter.format(m);
    }

    public synchronized static File createFileFromBytes(String fname, byte[] data) throws FileNotFoundException, IOException
    {
        File myFile = new File(fname);
        FileOutputStream fileOutputStream = new FileOutputStream(myFile);
        fileOutputStream.write(data);
        fileOutputStream.close();
        return myFile;
    }

    public synchronized static boolean createFileFromString(String fname, String data)
    {
        try
        {
            File MyFile = new File(fname);
            if (MyFile.exists() == false)
            {
                MyFile.createNewFile();
            } else
            {
                MyFile.delete();
                MyFile.createNewFile();
            }
            Writer out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(fname), "UTF-8"));

            out.write(data);
            out.flush();
            out.close();

        } catch (IOException e)
        {
            System.out.println("KABOOM :: " + Utils.class
                    .getName() + " :: " + e.toString());
            System.out.println("file name is : " + fname);
            return false;
        }

        return true;
    }

    public synchronized static byte[] getBytesFromFile(String fname) throws IOException
    {

        File file = new File(fname);
        byte[] bytes;
        InputStream is = new FileInputStream(file);
        long length = file.length();
        if (length > Integer.MAX_VALUE)
        {
            // File is too large
        }
        bytes = new byte[(int) length];
        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
                && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0)
        {
            offset += numRead;
        }
        if (offset < bytes.length)
        {
            throw new IOException("Could not completely read file " + file.getName());
        }
        is.close();
        return bytes;
    }

    public synchronized static List<String> getStringsFromFile(String fpath) throws Exception
    {
        List<String> retvalue = new ArrayList<>();

        FileInputStream fstream = new FileInputStream(fpath);
        // Get the object of DataInputStream
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String strLine;

        //Read File Line By Line
        while ((strLine = br.readLine()) != null)
        {
            // Print the content on the console
            String s = strLine;
            retvalue.add(s);
        }
        //Close the input stream
        in.close();

        return retvalue;
    }

    public synchronized static String getStringFromFile(String fpath) throws Exception
    {
        StringBuilder s = new StringBuilder();
        // Open the file that is the first
        // command line parameter

        FileInputStream fstream = new FileInputStream(fpath);
        // Get the object of DataInputStream
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        String strLine;

        //Read File Line By Line
        while ((strLine = br.readLine()) != null)
        {
            // Print the content on the console
            s.append(strLine);
        }
        //Close the input stream
        in.close();

        return s.toString();
    }

    public static String getStringFromUrl(String url) throws Exception
    {
        URL website = new URL(url);
        URLConnection connection = website.openConnection();
        BufferedReader in = new BufferedReader(
                new InputStreamReader(
                        connection.getInputStream()));

        StringBuilder response = new StringBuilder();
        String inputLine;

        while ((inputLine = in.readLine()) != null)
        {
            response.append(inputLine);
        }

        in.close();

        return response.toString();
    }

    public static byte[] getBytesFromUrl(String url) throws MalformedURLException, IOException
    {
        URL u = new URL(url);
        URLConnection uc = u.openConnection();
        String contentType = uc.getContentType();
        int contentLength = uc.getContentLength();
        if (contentType.startsWith("text/") || contentLength == -1)
        {
            throw new IOException("This is not a binary file.");
        }
        InputStream raw = uc.getInputStream();
        InputStream in = new BufferedInputStream(raw);
        byte[] data = new byte[contentLength];
        int bytesRead = 0;
        int offset = 0;
        while (offset < contentLength)
        {
            bytesRead = in.read(data, offset, data.length - offset);
            if (bytesRead == -1)
            {
                break;
            }
            offset += bytesRead;
        }
        in.close();

        if (offset != contentLength)
        {
            throw new IOException("Only read " + offset + " bytes; Expected " + contentLength + " bytes");
        }

        return data;
    }

    public static boolean checkIfFileExists(String filePathString)
    {
        File f = new File(filePathString);
        return f.exists() && !f.isDirectory();
    }

}
