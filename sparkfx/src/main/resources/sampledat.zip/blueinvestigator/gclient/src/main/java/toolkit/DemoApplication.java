/****************************************************************************
 **
 ** This file is part of yFiles for JavaFX 1.0.
 ** 
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2014 by yWorks GmbH, Vor dem Kreuzberg 28, 
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/
package toolkit;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Base class for demos that makes the use of {@link Application} easier
 * by implementing the main and start method and collecting the data
 * to do this from abstract getter methods that clients have to implement.
 * <p>
 *   The getter for event handler methods are implemented by default to return null.
 * </p>
 */
public abstract class DemoApplication extends Application {
  private static final String DEFAULT_CSS_FILE_NAME = "toolkit/DemoApplication.css";

  @Override
  public void start(Stage primaryStage) throws IOException {
    setup();
    Parent sceneRoot = getSceneRoot();

    Scene scene = new Scene(sceneRoot, getSceneWidth(), getSceneHeight());

    String cssFileName = getCssFileName();
    if (cssFileName != null) {
      scene.getStylesheets().add(cssFileName);
    }

    if (getOnCloseRequestHandler() != null){
      primaryStage.setOnCloseRequest(getOnCloseRequestHandler());
    }
    if (getOnHiddenHandler() != null){
      primaryStage.setOnHidden(getOnHiddenHandler());
    }
    if (getOnHidingHandler() != null){
      primaryStage.setOnHiding(getOnHidingHandler());
    }
    if (getOnShowingHandler() != null){
      primaryStage.setOnShowing(getOnShowingHandler());
    }
    if (getOnShownHandler() != null){
      primaryStage.setOnShown(getOnShownHandler());
    }

    primaryStage.getIcons().addAll(
        new Image("toolkit/resources/logo_29.png"),
        new Image("toolkit/resources/logo_36.png"),
        new Image("toolkit/resources/logo_48.png"),
        new Image("toolkit/resources/logo_57.png"),
        new Image("toolkit/resources/logo_129.png"));
    primaryStage.setTitle(getTitle());
    primaryStage.setScene(scene);
    primaryStage.show();
  }

  /**
   * Specifies the width of the scene. Used to construct the scene in the {@link #start(javafx.stage.Stage)} method.
   */
  public int getSceneWidth() {
    return 1400;
  }

  /**
   * Specifies the height of the scene. Used to construct the scene in the {@link #start(javafx.stage.Stage)} method.
   */
  public int getSceneHeight() {
    return 850;
  }

  /**
   * Method that is called prior to building the demo scene root.
   */
  public void setup(){}

  /**
   * Returns the name of the CSS file used for the demo application.
   */
  public String getCssFileName() {
    return DEFAULT_CSS_FILE_NAME;
  }

  /**
   * Returns the root for the scene graph of the demo.
   * The result of this will be passed to {@link Scene#setRoot(javafx.scene.Parent)}.
   */
  public abstract Parent getSceneRoot() throws IOException;

  /**
   * Returns the title of the stage for this demo.
   */
  public abstract String getTitle();

  /**
   * Returns a handler that is passed to the stages {@link Stage#setOnShown(javafx.event.EventHandler)} method.
   * The default implementation in this class returns null.
   */
  public EventHandler getOnShownHandler(){
    return null;
  }

  /**
   * Returns a handler that is passed to the stages {@link Stage#setOnShowing(javafx.event.EventHandler)} method.
   * The default implementation in this class returns null.
   */
  public EventHandler getOnShowingHandler(){
    return null;
  }

  /**
   * Returns a handler that is passed to the stages {@link Stage#setOnHidden(javafx.event.EventHandler)} method.
   * The default implementation in this class returns null.
   */
  public EventHandler getOnHiddenHandler(){
    return null;
  }

  /**
   * Returns a handler that is passed to the stages {@link Stage#setOnHiding(javafx.event.EventHandler)} method.
   * The default implementation in this class returns null.
   */
  public EventHandler getOnHidingHandler(){
    return null;
  }

  /**
   * Returns a handler that is passed to the stages {@link Stage#setOnCloseRequest(javafx.event.EventHandler)} method.
   * The default implementation in this class returns null.
   */
  public EventHandler getOnCloseRequestHandler(){
    return null;
  }

}
