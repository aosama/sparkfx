CREATE DATABASE  IF NOT EXISTS `sampledata` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sampledata`;
-- MySQL dump 10.13  Distrib 5.7.12, for osx10.9 (x86_64)
--
-- Host: localhost    Database: sampledata
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cellowner`
--

DROP TABLE IF EXISTS `cellowner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cellowner` (
  `ownershipId` bigint(20) NOT NULL AUTO_INCREMENT,
  `personId` bigint(20) NOT NULL,
  `cellnumber` varchar(20) NOT NULL,
  `startdate` datetime NOT NULL,
  `enddate` datetime NOT NULL,
  `recorddate` datetime NOT NULL,
  PRIMARY KEY (`ownershipId`),
  KEY `FK_cellowner_people_personId` (`personId`),
  KEY `FK_cellowner_tblcellphones_cellphonenumber` (`cellnumber`),
  CONSTRAINT `FK_cellowner_people_personId` FOREIGN KEY (`personId`) REFERENCES `people` (`personId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_cellowner_tblcellphones_cellphonenumber` FOREIGN KEY (`cellnumber`) REFERENCES `tblcellphones` (`cellphonenumber`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cellowner`
--

LOCK TABLES `cellowner` WRITE;
/*!40000 ALTER TABLE `cellowner` DISABLE KEYS */;
INSERT INTO `cellowner` VALUES (2,1,'01001491278','2014-06-17 18:51:54','2014-06-16 18:51:53','2014-06-16 18:51:58'),(3,3,'01001491280','2014-07-15 03:06:58','2014-07-31 03:07:01','2014-07-15 03:07:05');
/*!40000 ALTER TABLE `cellowner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people` (
  `personId` bigint(20) NOT NULL AUTO_INCREMENT,
  `personName` varchar(50) NOT NULL,
  `nationalid` varchar(15) NOT NULL,
  PRIMARY KEY (`personId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,'John Smith','123456'),(2,'Justin Case','654321'),(3,'John Ellis','854678');
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbladdress`
--

DROP TABLE IF EXISTS `tbladdress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladdress` (
  `addressid` int(11) NOT NULL AUTO_INCREMENT,
  `addresstext` varchar(50) NOT NULL,
  PRIMARY KEY (`addressid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbladdress`
--

LOCK TABLES `tbladdress` WRITE;
/*!40000 ALTER TABLE `tbladdress` DISABLE KEYS */;
INSERT INTO `tbladdress` VALUES (1,'263 DriveWay Road');
/*!40000 ALTER TABLE `tbladdress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbankaccount`
--

DROP TABLE IF EXISTS `tblbankaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblbankaccount` (
  `accountNumber` varchar(255) NOT NULL,
  `bankid` int(11) NOT NULL,
  `personid` bigint(20) NOT NULL,
  PRIMARY KEY (`accountNumber`),
  KEY `FK_tblbankaccount_tblbanks_bankid` (`bankid`),
  KEY `FK_tblbankaccount_people_personId` (`personid`),
  CONSTRAINT `FK_tblbankaccount_people_personId` FOREIGN KEY (`personid`) REFERENCES `people` (`personId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tblbankaccount_tblbanks_bankid` FOREIGN KEY (`bankid`) REFERENCES `tblbanks` (`bankid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbankaccount`
--

LOCK TABLES `tblbankaccount` WRITE;
/*!40000 ALTER TABLE `tblbankaccount` DISABLE KEYS */;
INSERT INTO `tblbankaccount` VALUES ('ac12345',1,1),('ac220',2,2),('ac650',3,3);
/*!40000 ALTER TABLE `tblbankaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbanks`
--

DROP TABLE IF EXISTS `tblbanks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblbanks` (
  `bankid` int(11) NOT NULL AUTO_INCREMENT,
  `bankname` varchar(100) NOT NULL,
  PRIMARY KEY (`bankid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbanks`
--

LOCK TABLES `tblbanks` WRITE;
/*!40000 ALTER TABLE `tblbanks` DISABLE KEYS */;
INSERT INTO `tblbanks` VALUES (1,'CitiBank'),(2,'HSBC'),(3,'JP Morgan'),(4,'Barclays');
/*!40000 ALTER TABLE `tblbanks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcellcalls`
--

DROP TABLE IF EXISTS `tblcellcalls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcellcalls` (
  `callid` bigint(20) NOT NULL AUTO_INCREMENT,
  `fromcell` varchar(255) NOT NULL,
  `tocell` varchar(255) NOT NULL,
  `starttime` datetime NOT NULL,
  `endtime` datetime NOT NULL,
  `recordcreateddate` datetime NOT NULL,
  PRIMARY KEY (`callid`),
  KEY `FK_tblcellcalls_tblcellphones_cellphonenumber` (`fromcell`),
  KEY `FK_2` (`tocell`),
  CONSTRAINT `FK_2` FOREIGN KEY (`tocell`) REFERENCES `tblcellphones` (`cellphonenumber`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tblcellcalls_tblcellphones_cellphonenumber` FOREIGN KEY (`fromcell`) REFERENCES `tblcellphones` (`cellphonenumber`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22532 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcellcalls`
--

LOCK TABLES `tblcellcalls` WRITE;
/*!40000 ALTER TABLE `tblcellcalls` DISABLE KEYS */;
INSERT INTO `tblcellcalls` VALUES (8952,'01001491278','1001491353','2014-05-21 21:04:59','2014-05-21 21:04:59','2014-05-21 21:04:59'),(8967,'01001491278','1001491382','2014-05-21 21:05:00','2014-05-21 21:05:00','2014-05-21 21:05:00'),(8971,'1001491314','01001491278','2014-05-21 21:05:00','2014-05-21 21:05:00','2014-05-21 21:05:00'),(8992,'1001491329','01001491278','2014-05-21 21:05:00','2014-05-21 21:05:00','2014-05-21 21:05:00'),(9007,'01001491278','1001491331','2014-05-21 21:05:01','2014-05-21 21:05:01','2014-05-21 21:05:01'),(9066,'01001491278','1001492289','2014-05-21 21:05:03','2014-05-21 21:05:03','2014-05-21 21:05:03'),(9134,'1001491386','01001491278','2014-05-21 21:05:05','2014-05-21 21:05:05','2014-05-21 21:05:05'),(9164,'1001491349','01001491278','2014-05-21 21:05:06','2014-05-21 21:05:06','2014-05-21 21:05:06'),(9225,'01001491278','1001491357','2014-05-21 21:05:08','2014-05-21 21:05:08','2014-05-21 21:05:08'),(9253,'01001491278','1001491325','2014-05-21 21:05:09','2014-05-21 21:05:09','2014-05-21 21:05:09'),(9338,'01001491278','1001491335','2014-05-21 21:05:12','2014-05-21 21:05:12','2014-05-21 21:05:12'),(9416,'1001491332','01001491278','2014-05-21 21:05:14','2014-05-21 21:05:14','2014-05-21 21:05:14'),(9442,'1001491348','01001491278','2014-05-21 21:05:15','2014-05-21 21:05:15','2014-05-21 21:05:15'),(9448,'1001491360','01001491278','2014-05-21 21:05:15','2014-05-21 21:05:15','2014-05-21 21:05:15'),(22531,'1001491357','1001491360','2014-05-30 11:33:36','2014-05-30 11:33:38','2014-05-30 11:33:40');
/*!40000 ALTER TABLE `tblcellcalls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcellphones`
--

DROP TABLE IF EXISTS `tblcellphones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcellphones` (
  `cellphonenumber` varchar(255) NOT NULL,
  `recordcreateddate` datetime NOT NULL,
  PRIMARY KEY (`cellphonenumber`),
  UNIQUE KEY `UK_tblcellphones_cellphonenumb` (`cellphonenumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcellphones`
--

LOCK TABLES `tblcellphones` WRITE;
/*!40000 ALTER TABLE `tblcellphones` DISABLE KEYS */;
INSERT INTO `tblcellphones` VALUES ('01001491278','2014-04-30 01:38:07'),('01001491279','2014-04-30 01:38:12'),('01001491280','2014-05-21 19:20:04'),('1001491290','2014-05-21 19:32:23'),('1001491291','2014-05-21 19:32:23'),('1001491292','2014-05-21 19:32:23'),('1001491293','2014-05-21 19:32:23'),('1001491294','2014-05-21 19:32:23'),('1001491295','2014-05-21 19:32:23'),('1001491296','2014-05-21 19:32:23'),('1001491297','2014-05-21 19:32:23'),('1001491298','2014-05-21 19:32:23'),('1001491299','2014-05-21 19:32:23'),('1001491300','2014-05-21 19:32:23'),('1001491301','2014-05-21 19:32:23'),('1001491302','2014-05-21 19:32:23'),('1001491303','2014-05-21 19:32:23'),('1001491304','2014-05-21 19:32:23'),('1001491305','2014-05-21 19:32:23'),('1001491306','2014-05-21 19:32:23'),('1001491307','2014-05-21 19:32:23'),('1001491308','2014-05-21 19:32:23'),('1001491309','2014-05-21 19:32:23'),('1001491310','2014-05-21 19:32:23'),('1001491311','2014-05-21 19:32:23'),('1001491312','2014-05-21 19:32:23'),('1001491313','2014-05-21 19:32:23'),('1001491314','2014-05-21 19:32:23'),('1001491315','2014-05-21 19:32:24'),('1001491316','2014-05-21 19:32:24'),('1001491317','2014-05-21 19:32:24'),('1001491318','2014-05-21 19:32:24'),('1001491319','2014-05-21 19:32:24'),('1001491320','2014-05-21 19:32:24'),('1001491321','2014-05-21 19:32:24'),('1001491322','2014-05-21 19:32:24'),('1001491323','2014-05-21 19:32:24'),('1001491324','2014-05-21 19:32:24'),('1001491325','2014-05-21 19:32:24'),('1001491326','2014-05-21 19:32:24'),('1001491327','2014-05-21 19:32:24'),('1001491328','2014-05-21 19:32:24'),('1001491329','2014-05-21 19:32:24'),('1001491330','2014-05-21 19:32:24'),('1001491331','2014-05-21 19:32:24'),('1001491332','2014-05-21 19:32:24'),('1001491333','2014-05-21 19:32:24'),('1001491334','2014-05-21 19:32:24'),('1001491335','2014-05-21 19:32:24'),('1001491336','2014-05-21 19:32:24'),('1001491337','2014-05-21 19:32:24'),('1001491338','2014-05-21 19:32:24'),('1001491339','2014-05-21 19:32:25'),('1001491340','2014-05-21 19:32:25'),('1001491341','2014-05-21 19:32:25'),('1001491342','2014-05-21 19:32:25'),('1001491343','2014-05-21 19:32:25'),('1001491344','2014-05-21 19:32:25'),('1001491345','2014-05-21 19:32:25'),('1001491346','2014-05-21 19:32:25'),('1001491347','2014-05-21 19:32:25'),('1001491348','2014-05-21 19:32:25'),('1001491349','2014-05-21 19:32:25'),('1001491350','2014-05-21 19:32:25'),('1001491351','2014-05-21 19:32:25'),('1001491352','2014-05-21 19:32:25'),('1001491353','2014-05-21 19:32:25'),('1001491354','2014-05-21 19:32:25'),('1001491355','2014-05-21 19:32:25'),('1001491356','2014-05-21 19:32:25'),('1001491357','2014-05-21 19:32:25'),('1001491358','2014-05-21 19:32:25'),('1001491359','2014-05-21 19:32:25'),('1001491360','2014-05-21 19:32:25'),('1001491361','2014-05-21 19:32:25'),('1001491362','2014-05-21 19:32:25'),('1001491363','2014-05-21 19:32:25'),('1001491364','2014-05-21 19:32:25'),('1001491365','2014-05-21 19:32:25'),('1001491366','2014-05-21 19:32:25'),('1001491367','2014-05-21 19:32:26'),('1001491368','2014-05-21 19:32:26'),('1001491369','2014-05-21 19:32:26'),('1001491370','2014-05-21 19:32:26'),('1001491371','2014-05-21 19:32:26'),('1001491372','2014-05-21 19:32:26'),('1001491373','2014-05-21 19:32:26'),('1001491374','2014-05-21 19:32:26'),('1001491375','2014-05-21 19:32:26'),('1001491376','2014-05-21 19:32:26'),('1001491377','2014-05-21 19:32:26'),('1001491378','2014-05-21 19:32:26'),('1001491379','2014-05-21 19:32:26'),('1001491380','2014-05-21 19:32:26'),('1001491381','2014-05-21 19:32:26'),('1001491382','2014-05-21 19:32:26'),('1001491383','2014-05-21 19:32:26'),('1001491384','2014-05-21 19:32:26'),('1001491385','2014-05-21 19:32:26'),('1001491386','2014-05-21 19:32:26'),('1001492287','2014-05-21 19:33:00'),('1001492288','2014-05-21 19:33:00'),('1001492289','2014-05-21 19:33:00'),('1001492290','2014-05-21 19:33:00');
/*!40000 ALTER TABLE `tblcellphones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcompanies`
--

DROP TABLE IF EXISTS `tblcompanies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcompanies` (
  `registrationNumber` varchar(255) NOT NULL,
  `CompanyName` varchar(50) NOT NULL,
  PRIMARY KEY (`registrationNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcompanies`
--

LOCK TABLES `tblcompanies` WRITE;
/*!40000 ALTER TABLE `tblcompanies` DISABLE KEYS */;
INSERT INTO `tblcompanies` VALUES ('RN00001','ACME Industrial'),('RN00002','Universal Exports'),('RN00003','United Services'),('RN00004','International Consultancy Services');
/*!40000 ALTER TABLE `tblcompanies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcompanybankaccount`
--

DROP TABLE IF EXISTS `tblcompanybankaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcompanybankaccount` (
  `companyregistrationNumber` varchar(255) NOT NULL,
  `bankaccountnumber` varchar(255) NOT NULL,
  `bankid` int(11) NOT NULL,
  PRIMARY KEY (`companyregistrationNumber`,`bankaccountnumber`,`bankid`),
  UNIQUE KEY `UK_tblcompanybankaccount_banka` (`bankaccountnumber`),
  KEY `FK_tblcompanybankaccount_tblbanks_bankid` (`bankid`),
  CONSTRAINT `FK_tblcompanybankaccount_tblbanks_bankid` FOREIGN KEY (`bankid`) REFERENCES `tblbanks` (`bankid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tblcompanybankaccount_tblcompanies_registrationNumber` FOREIGN KEY (`companyregistrationNumber`) REFERENCES `tblcompanies` (`registrationNumber`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcompanybankaccount`
--

LOCK TABLES `tblcompanybankaccount` WRITE;
/*!40000 ALTER TABLE `tblcompanybankaccount` DISABLE KEYS */;
INSERT INTO `tblcompanybankaccount` VALUES ('RN00003','ACUnitedServices',1),('RN00001','AC56789',2),('RN00004','ACInternationalConsultancy',3),('RN00002','ACUEXPORTS',4);
/*!40000 ALTER TABLE `tblcompanybankaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcompanybanktransfer`
--

DROP TABLE IF EXISTS `tblcompanybanktransfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcompanybanktransfer` (
  `fromAccountNumber` varchar(255) NOT NULL,
  `toAccountNumber` varchar(255) NOT NULL,
  `transferDate` datetime NOT NULL,
  `transferAmount` decimal(8,2) NOT NULL,
  KEY `FK_fggg` (`fromAccountNumber`),
  KEY `FK_ggggggg` (`toAccountNumber`),
  CONSTRAINT `FK_fggg` FOREIGN KEY (`fromAccountNumber`) REFERENCES `tblcompanybankaccount` (`bankaccountnumber`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ggggggg` FOREIGN KEY (`toAccountNumber`) REFERENCES `tblcompanybankaccount` (`bankaccountnumber`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcompanybanktransfer`
--

LOCK TABLES `tblcompanybanktransfer` WRITE;
/*!40000 ALTER TABLE `tblcompanybanktransfer` DISABLE KEYS */;
INSERT INTO `tblcompanybanktransfer` VALUES ('AC56789','ACUEXPORTS','2014-08-27 10:52:28',100.00),('AC56789','ACUnitedServices','2014-08-28 10:54:51',200.00),('AC56789','ACInternationalConsultancy','2014-08-27 10:55:06',500.00);
/*!40000 ALTER TABLE `tblcompanybanktransfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblcompanyowner`
--

DROP TABLE IF EXISTS `tblcompanyowner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcompanyowner` (
  `companyregistrationnumber` varchar(255) NOT NULL,
  `personid` bigint(20) NOT NULL,
  PRIMARY KEY (`companyregistrationnumber`,`personid`),
  KEY `FK_tblcompanyowner_people_personId` (`personid`),
  CONSTRAINT `FK_tblcompanyowner_people_personId` FOREIGN KEY (`personid`) REFERENCES `people` (`personId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tblcompanyowner_tblcompanies_registrationNumber` FOREIGN KEY (`companyregistrationnumber`) REFERENCES `tblcompanies` (`registrationNumber`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcompanyowner`
--

LOCK TABLES `tblcompanyowner` WRITE;
/*!40000 ALTER TABLE `tblcompanyowner` DISABLE KEYS */;
INSERT INTO `tblcompanyowner` VALUES ('RN00001',1),('RN00002',2),('RN00003',3),('RN00004',4);
/*!40000 ALTER TABLE `tblcompanyowner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpersonaddress`
--

DROP TABLE IF EXISTS `tblpersonaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpersonaddress` (
  `personid` bigint(20) NOT NULL,
  `addressid` int(11) NOT NULL,
  PRIMARY KEY (`personid`),
  KEY `FK_tblpersonaddress_tbladdress_addressid` (`addressid`),
  CONSTRAINT `FK_tblpersonaddress_people_personId` FOREIGN KEY (`personid`) REFERENCES `people` (`personId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tblpersonaddress_tbladdress_addressid` FOREIGN KEY (`addressid`) REFERENCES `tbladdress` (`addressid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpersonaddress`
--

LOCK TABLES `tblpersonaddress` WRITE;
/*!40000 ALTER TABLE `tblpersonaddress` DISABLE KEYS */;
INSERT INTO `tblpersonaddress` VALUES (2,1),(3,1),(4,1);
/*!40000 ALTER TABLE `tblpersonaddress` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-15  1:56:42
